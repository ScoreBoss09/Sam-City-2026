import * as THREE from 'three';
import { UNIT, WALL_H, WALL_T, DOOR_W, TILE } from '../config.js';
import { FACADES } from '../data/buildings.js';
import { doorOffset } from '../data/layouts.js';
import { facadeMaterial, signTexture, roofMaterial, glassMaterial } from './Textures.js';
import { ADS } from '../data/adverts.js';
import { levelPlan, flightH, slabHoles, laneRect, upperFurniture, LANE_W } from '../world/Levels.js';
import { makeFurniture, FURN } from './Furniture.js';
import { wallPieces } from '../data/homes.js';
import { mulberry32 } from '../util.js';
import { Assets } from './Assets.js';
import { shellModel } from './GLB.js';

const unit = new THREE.BoxGeometry(1, 1, 1);
const mcache = {};
export function stdMat(c, o = {}) { const k = c + JSON.stringify(o); return mcache[k] || (mcache[k] = new THREE.MeshStandardMaterial({ color: c, roughness: 0.9, ...o })); }
function box(g, w, h, d, c, x, y, z, o) { const m = new THREE.Mesh(unit, stdMat(c, o)); m.scale.set(w, h, d); m.position.set(x, y + h / 2, z); m.castShadow = true; m.receiveShadow = true; g.add(m); return m; }

/** Box whose UVs are in metres, so the facade texture tiles at its real-world size. */
function wallGeo(w, h, d) {
  const g = new THREE.BoxGeometry(w, h, d), uv = g.attributes.uv;
  const dims = [[d, h], [d, h], [w, d], [w, d], [w, h], [w, h]];
  for (let f = 0; f < 6; f++) for (let k = 0; k < 4; k++) { const i = f * 4 + k; uv.setXY(i, uv.getX(i) * dims[f][0] / 4, uv.getY(i) * dims[f][1] / WALL_H); }
  return g;
}
function prism(w, h, d) { // gable roof, ridge along z, base y=0
  const a = [-w / 2, 0, -d / 2], b = [w / 2, 0, -d / 2], c = [0, h, -d / 2], a2 = [-w / 2, 0, d / 2], b2 = [w / 2, 0, d / 2], c2 = [0, h, d / 2];
  const tris = [a, c, b, a2, b2, c2, a, a2, c2, a, c2, c, b, c, c2, b, c2, b2, a, b, b2, a, b2, a2];   // (the last two close the underside: no peeking up into the roof)
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(tris.flat(), 3)); g.computeVertexNormals();
  const uv = []; for (const [x, y, z] of tris) uv.push((z * 0.55 + x * 0.12) , (y * 1.15 + Math.abs(x) * 0.35)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); return g;
}

/** Textured (or plain fallback) material for interiors; rx/ry = repeats. */
const imat = {};
function texMat(key, fallback, rx = 1, ry = 1, tint = 0xffffff, o = {}) {
  const k = key + '|' + fallback + '|' + rx + '|' + ry + '|' + tint + JSON.stringify(o); if (imat[k]) return imat[k];
  const map = key && Assets.has(key) ? Assets.tex(key, rx, ry) : null;
  return (imat[k] = new THREE.MeshStandardMaterial({ color: map ? tint : fallback, map, roughness: 0.9, ...o }));
}
/** Floor + wall-lining look per interior layout. */
const INTERIOR = {
  hut: ['floor_wood_dark', 0x8a6a44, 'int_planks', 0xa98660], cabin: ['floor_wood_dark', 0x8a6a44, 'int_planks', 0xa98660], shed: ['floor_wood_dark', 0x8a6a44, 'int_planks', 0xa98660],
  terminalhut: ['floor_wood_dark', 0x8a6a44, 'int_planks', 0xa98660], yard: ['ground_pavement', 0x999999, 'int_stucco', 0xc9bfa0],
  tavern: ['floor_wood_dark', 0x7a5a3a, 'int_wallpaper_red', 0xa04a40], school: ['floor_wood', 0xa6825a, 'int_paint_yellow', 0xe0cf8a],
  shop: ['floor_tile', 0xd8dade, 'int_paint_blue', 0x9ab4d0], clinic: ['floor_tile', 0xd8dade, 'int_paint_green', 0xa8d0b0], police: ['floor_tile_grey', 0xaaaeb4, 'int_paint_grey', 0xaab0b8],
  office: ['floor_carpet_green', 0x6a8a70, 'int_wallpaper_white', 0xe6e2d8], lobby: ['floor_tile_grey', 0xaaaeb4, 'int_wallpaper_white', 0xe6e2d8], townhall: ['floor_carpet_red', 0x9a4a40, 'int_wallpaper_white', 0xe6e2d8],
  factory: ['ground_pavement', 0x999999, 'int_paint_grey', 0xaab0b8], power: ['ground_pavement', 0x999999, 'int_paint_grey', 0xaab0b8], pump: ['ground_pavement', 0x999999, 'int_paint_grey', 0xaab0b8],
  depot: ['ground_pavement', 0x999999, 'int_stucco', 0xc9bfa0], contractor: ['floor_wood', 0xa6825a, 'int_stucco', 0xc9bfa0],
};
const HOME_PAPER = [['int_wallpaper_green', 0x8ab48a], ['int_wallpaper_blue', 0x9ab0d0], ['int_wallpaper_red', 0xa04a40], ['int_paint_yellow', 0xe0cf8a]];
/** Inward-facing wall lining plane (metre UVs: one texture tile = 3 m). */
function lining(g, len, h, cx, cz, rotY, mat, y0 = 0.14) {
  const geo = new THREE.PlaneGeometry(len, h), uv = geo.attributes.uv;
  if (ALIGN) { geo.rotateY(rotY); alignUV(geo, cx, y0 + h / 2, cz, Math.abs(Math.cos(rotY)) > 0.5); mat = maskMat(mat); }
  else for (let i = 0; i < uv.count; i++) uv.setXY(i, uv.getX(i) * len / 3, uv.getY(i) * h / 3);
  const m = new THREE.Mesh(geo, mat); m.position.set(cx, y0 + h / 2, cz); if (!ALIGN) m.rotation.y = rotY; m.receiveShadow = true; g.add(m);
}
/**
 * While a building's main walls are made: its size, the window mask and the glass sheets. Wall and lining UVs are then
 * measured from the building's own corner, so the window holes in the facade line up through the wall and its lining.
 */
let ALIGN = null;
function alignUV(geo, cx, cy, cz, alongX) {
  const pos = geo.attributes.position, nor = geo.attributes.normal, uv = geo.attributes.uv;
  for (let i = 0; i < pos.count; i++) {
    if (Math.abs(nor.getY(i)) > 0.5) { uv.setXY(i, 0.02, 0.97); continue; }
    const x = pos.getX(i) + cx, y = pos.getY(i) + cy, z = pos.getZ(i) + cz;
    uv.setXY(i, alongX ? (x + ALIGN.W / 2) / 4 : (z + ALIGN.D / 2) / 4, y / WALL_H);
  }
}
const masked = {};
function maskMat(mat) { const k = mat.uuid + '|' + (ALIGN.mask ? ALIGN.mask.uuid : '-'); if (masked[k]) return masked[k];   // per wallpaper AND per facade: each style has its windows in different places
 const m = mat.clone(); m.alphaMap = ALIGN.mask; m.alphaTest = 0.5; return (masked[k] = m); }
const RUSTIC = ['timber', 'logs', 'stone'];
const rustic0 = (def) => ['logs', 'timber'].includes(def.wall);
const shadeHex = (hex, f) => { const c = new THREE.Color(hex); c.multiplyScalar(f); return c.getHex(); };
function addWall(g, cols, mat, cx, cz, sx, sz, h = null, y = 0) {
  const H = h, alongX = sx >= sz; let geo;
  if (ALIGN) { geo = new THREE.BoxGeometry(sx, H, sz); alignUV(geo, cx, y + H / 2, cz, alongX); } else geo = wallGeo(sx, H, sz);
  const m = new THREE.Mesh(geo, mat); m.position.set(cx, y + H / 2, cz); m.castShadow = true; m.receiveShadow = true; g.add(m);
  if (ALIGN && Math.max(sx, sz) > 0.5) { const p = new THREE.Mesh(new THREE.PlaneGeometry(Math.max(sx, sz), H), glassMaterial()); p.position.set(cx, y + H / 2, cz); p.rotation.y = alongX ? 0 : Math.PI / 2; p.castShadow = false; p.receiveShadow = false; g.add(p); }
  if (y === 0) cols.push(ALIGN ? { cx, cz, sx, sz, h: ALIGN.H + 0.5 } : { cx, cz, sx, sz });
}

/**
 * Drawn curtains behind every window of a home (one draw call, shown after dark while someone's in). The windows are
 * where the facade's window holes are: every 4 m along each wall, the same positions the outside texture paints.
 */
const CURTAIN_COLS = [0x8a2a3a, 0x3a5a8a, 0xc8a24a, 0x4a7a4a, 0xd8c8b0, 0x7a4a8a, 0xb8603a];
/** Swap the procedural walls, linings, painted glass and front clutter for a Blender shell (real windows where the model has them). Keeps floors, doors, bins and colliders. */
function useShell(g, roof, cols, shell, { W, D, T, H, keep }) {
  const bb = new THREE.Box3(), c = new THREE.Vector3(), glass = glassMaterial();
  for (const o of [...g.children]) {
    if (o.userData.keep) continue;
    if (o.isMesh && (keep.includes(o.material) || o.material === glass)) { g.remove(o); continue; }
    bb.setFromObject(o); bb.getCenter(c);
    const outside = Math.abs(c.x) > W / 2 - T - 0.05 || Math.abs(c.z) > D / 2 - T - 0.05, kerb = c.z > D / 2 + 0.25 && bb.max.y < 1.0 && Math.abs(c.x) < W / 2 - 0.3;
    if (outside && !kerb && bb.max.y > 0.2) g.remove(o);
  }
  roof.clear(); g.add(...shell.shell.children); if (shell.glass) for (const m of [...shell.glass.children]) { m.material = glass; m.castShadow = false; g.add(m); }
  if (shell.roof) { shell.roof.position.y = -H; roof.add(shell.roof); }
  if (W === 8) cols.push({ cx: 1.7, cz: D / 2 + 0.38, sx: 3.2, sz: 0.76, h: 2.8 });   // the bay window
}
function buildCurtains(def, g, uid, T, door, dw) {
  const f = FACADES[def.wall] || FACADES.tan, n = f.wins; if (!n || f.kind === 'curtain') return null;
  const ww = (f.kind === 'logs' ? 16 : n === 1 ? 44 : f.kind === 'tudor' ? 14 : 18) / 16, xs = (n === 2 ? (f.kind === 'tudor' ? [9, 41] : [7, 39]) : [Math.round((64 - ww * 16) / 2)]).map((x) => x / 16 + ww / 2);
  const W = def.w * UNIT, D = def.d * UNIT, floors = Math.max(1, def.floors || 1), grp = new THREE.Group(), col = CURTAIN_COLS[uid % CURTAIN_COLS.length], hgt = 1.62, yb = 0.86;
  // [wall length, centre of the wall's inner face, along x?, which way the room is]
  const walls = [[W, -D / 2 + T + 0.05, true, 1], [W, D / 2 - T - 0.05, true, -1], [D, -W / 2 + T + 0.05, false, 1], [D, W / 2 - T - 0.05, false, -1]];
  for (const [L, at, alongX, inward] of walls) for (let fl = 0; fl < floors; fl++) for (let k = 0; k * 4 < L; k++) for (const xc of xs) {
    const c = -L / 2 + k * 4 + xc; if (c - ww / 2 < -L / 2 + T + 0.05 || c + ww / 2 > L / 2 - T - 0.05) continue;
    if (alongX && inward < 0 && fl === 0 && c + ww / 2 > door - dw / 2 - 0.05 && c - ww / 2 < door + dw / 2 + 0.05) continue;   // not over the front door
    for (const side of [-1, 1]) {   // two halves, meeting in the middle
      const m = new THREE.Mesh(unit, stdMat(col, { roughness: 1 })), w2 = ww / 2 + 0.06;
      m.scale.set(alongX ? w2 : 0.04, hgt, alongX ? 0.04 : w2); const off = c + side * w2 / 2, y = fl * WALL_H + yb + hgt / 2 - 0.08;
      m.position.set(alongX ? off : at, y, alongX ? at : off); grp.add(m);
    }
  }
  if (!grp.children.length) return null;
  mergeByMaterial(grp); grp.userData.keep = true; grp.visible = false; g.add(grp); return grp;
}

/** Merge all static meshes of a group that share a material into one mesh (big draw-call saver). */
export function mergeByMaterial(root) {
  root.updateMatrixWorld(true); const inv = new THREE.Matrix4().copy(root.matrixWorld).invert(), buckets = new Map(), remove = [];
  root.traverse((o) => {
    if (!o.isMesh || o.isInstancedMesh || !o.geometry || Array.isArray(o.material)) return;
    for (let q = o; q && q !== root; q = q.parent) if (q.userData && q.userData.keep) return;
    const a = o.geometry.attributes, k = o.material.uuid + '|' + Object.keys(a).join(',') + '|' + !!o.geometry.index + '|' + o.castShadow + o.receiveShadow;
    let bk = buckets.get(k); if (!bk) buckets.set(k, bk = { mat: o.material, list: [], cast: o.castShadow, recv: o.receiveShadow, keys: Object.keys(a), indexed: !!o.geometry.index });
    bk.list.push(o); remove.push(o);
  });
  const mtx = new THREE.Matrix4(), nm = new THREE.Matrix3(), v = new THREE.Vector3();
  for (const bk of buckets.values()) {
    if (bk.list.length < 2) continue; const arrays = {}; for (const key of bk.keys) arrays[key] = []; const idx = []; let off = 0;
    for (const o of bk.list) {
      mtx.multiplyMatrices(inv, o.matrixWorld); nm.getNormalMatrix(mtx); const g = o.geometry, pos = g.attributes.position;
      for (const key of bk.keys) {
        const at = g.attributes[key];
        for (let i = 0; i < at.count; i++) {
          if (key === 'position') { v.fromBufferAttribute(at, i).applyMatrix4(mtx); arrays[key].push(v.x, v.y, v.z); }
          else if (key === 'normal') { v.fromBufferAttribute(at, i).applyMatrix3(nm).normalize(); arrays[key].push(v.x, v.y, v.z); }
          else for (let c = 0; c < at.itemSize; c++) arrays[key].push(at.array[i * at.itemSize + c]);
        }
      }
      if (bk.indexed) for (const i of g.index.array) idx.push(i + off); off += pos.count;
    }
    const geo = new THREE.BufferGeometry(); geo.userData.own = true; for (const key of bk.keys) geo.setAttribute(key, new THREE.Float32BufferAttribute(arrays[key], bk.list[0].geometry.attributes[key].itemSize)); if (bk.indexed) geo.setIndex(idx);
    const m = new THREE.Mesh(geo, bk.mat); m.castShadow = bk.cast; m.receiveShadow = bk.recv; root.add(m);
    for (const o of bk.list) { o.parent.remove(o); if (o.geometry.userData && o.geometry.userData.own) o.geometry.dispose(); }
  }
  return root;
}

/**
 * Turn every plain-coloured, untextured part into vertex colours on one shared material, so mergeByMaterial can
 * fold them all into a single mesh (dozens of little boxes in different colours = one draw call, not dozens).
 */
const VC = {};
export function colorize(root) {
  root.updateMatrixWorld(true);
  root.traverse((o) => {
    if (!o.isMesh || o.isInstancedMesh) return; for (let q = o; q && q !== root; q = q.parent) if (q.userData && q.userData.keep) return;
    const m = o.material; if (Array.isArray(m) || !m.isMeshStandardMaterial || m.map || m.transparent || m.vertexColors || m.flatShading || m.side !== THREE.FrontSide || (m.emissive && m.emissive.getHex() !== 0)) return;
    const r = 0.85, mt = 0.05, k = 'vc';   // one shared material for every plain colour (the tiny shine differences aren't worth a draw call each)
    const g = o.geometry.clone(), n = g.attributes.position.count, col = new Float32Array(n * 3); for (let i = 0; i < n; i++) { col[i * 3] = m.color.r; col[i * 3 + 1] = m.color.g; col[i * 3 + 2] = m.color.b; }
    g.setAttribute('color', new THREE.BufferAttribute(col, 3)); g.userData.own = true; o.geometry = g;
    o.material = VC[k] || (VC[k] = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: r, metalness: mt }));
  });
}
export function buildExterior(def, uid = 1, era = 2) {
  const r = buildExterior0(def, uid, era);
  // little things (sills, flower boxes, bins, bottles, lamps) don't need to cast shadows: far fewer shadow draws
  const v = new THREE.Vector3(), sz = new THREE.Vector3(); for (const root of [r.group, r.roof]) root.traverse((o) => { if (!o.isMesh || !o.castShadow) return; if (!o.geometry.boundingBox) o.geometry.computeBoundingBox(); o.geometry.boundingBox.getSize(sz); o.getWorldScale(v); const d = [sz.x * v.x, sz.y * v.y, sz.z * v.z].sort((a, b) => b - a); if (d[1] < 0.35 || d[0] < 0.6) o.castShadow = false; });
  colorize(r.group); colorize(r.roof); mergeByMaterial(r.group); mergeByMaterial(r.roof);
  r.glass = r.group.children.filter((o) => o.material === glassMaterial());   // hidden with the upstairs when far away
  return r;
}
function buildExterior0(def, uid = 1, era = 2) {
  if (def.id === 'lift') return buildLift(def);
  if (def.id === 'tunnel') return buildTunnel(def);
  if (def.park) return buildPark(def, uid);
  if (def.special_ext === 'stockyard') return buildStockyard(def);
  if (def.model && MODEL_BUILD) { const m = MODEL_BUILD(def.model); if (m) { const W = def.w * UNIT, D = def.d * UNIT; return { group: m, roof: new THREE.Group(), colliders: def.walkIn ? [] : [{ cx: 0, cz: 0, sx: W - 0.2, sz: D - 0.2, h: def.modelH || 4 }], height: def.modelH || 4, doors: [] }; } }
  if (def.special_ext === 'lockup') return buildLockup(def);
  if (def.special_ext === 'carpark') return buildCarPark(def);
  if (def.special_ext === 'farm') return buildFarm(def, uid);
  const W = def.w * UNIT, D = def.d * UNIT, H = def.floors * WALL_H, T = WALL_T, rnd = mulberry32(uid * 7919 + 13);
  const g = new THREE.Group(), roof = new THREE.Group(), cols = [], plan = levelPlan(def), roofCols = [];
  const mat = facadeMaterial(def.wall, true), door = doorOffset(def.w), dw = DOOR_W;
  ALIGN = { W, D, H, mask: mat.userData.mask };
  // how much room the plot leaves round the walls: eaves, paving and the like stay inside it (no poking into next door)
  const mx = (Math.ceil(W / TILE - 1e-6) * TILE - W) / 2, mz = (Math.ceil(D / TILE - 1e-6) * TILE - D) / 2;
  box(g, W + 2 * Math.min(0.35, Math.max(0, mx - 0.02)), 0.3, D + 2 * Math.min(0.35, Math.max(0, mz - 0.02)), 0x9a9b9c, 0, -0.2, 0);   // pavement slab
  const homey = ['house', 'apartments'].includes(def.layout), paper = HOME_PAPER[uid % HOME_PAPER.length];
  const look = INTERIOR[def.layout] || (homey ? ['floor_wood', 0xa6825a, paper[0], paper[1]] : ['floor_wood', 0xa6825a, 'int_stucco', 0xc9bfa0]);
  const floor = new THREE.Mesh(unit, texMat(look[0], look[1], W / 4, D / 4)); floor.scale.set(W - 0.1, 0.12, D - 0.1); floor.position.y = 0.08; floor.receiveShadow = true; g.add(floor);   // interior floor
  addWall(g, cols, mat, 0, -D / 2 + T / 2, W, T, H);                              // back
  addWall(g, cols, mat, -W / 2 + T / 2, 0, T, D - 2 * T, H);                      // left
  addWall(g, cols, mat, W / 2 - T / 2, 0, T, D - 2 * T, H);                       // right
  const fz = D / 2 - T / 2, l0 = -W / 2, l1 = door - dw / 2, r0 = door + dw / 2, r1 = W / 2;
  addWall(g, cols, mat, (l0 + l1) / 2, fz, l1 - l0, T, H);
  addWall(g, cols, mat, (r0 + r1) / 2, fz, r1 - r0, T, H);
  if (H > 2.6) addWall(g, [], mat, door, fz, dw, T, H - 2.6, 2.6);               // lintel
  box(g, 0.12, 2.6, 0.5, 0x2a2d33, door - dw / 2, 0, fz); box(g, 0.12, 2.6, 0.5, 0x2a2d33, door + dw / 2, 0, fz); box(g, dw, 0.12, 0.5, 0x2a2d33, door, 2.55, fz);
  // ceiling (stays when the roof is cut away)
  const ceilH = plan ? WALL_H : Math.min(H, WALL_H * 1.7);
  if (!plan) box(g, W - 2 * T, 0.12, D - 2 * T, 0xe8e4da, 0, ceilH - 0.1, 0, { emissive: 0xfff2d0, emissiveIntensity: 0.55 });
  // textured wall lining on the inside faces
  const lm = texMat(look[2], look[3], 1, 1, 0xb8b2a6), lh = ceilH - 0.24, iz = D / 2 - T - 0.02, ix = W / 2 - T - 0.02;
  lining(g, W - 2 * T, lh, 0, -D / 2 + T + 0.02, 0, lm);
  lining(g, D - 2 * T, lh, -ix, 0, Math.PI / 2, lm); lining(g, D - 2 * T, lh, ix, 0, -Math.PI / 2, lm);
  const fl0 = l1 - (-W / 2 + T), fr0 = (W / 2 - T) - r0;
  if (fl0 > 0.1) lining(g, fl0, lh, (-W / 2 + T + l1) / 2, iz, Math.PI, lm); if (fr0 > 0.1) lining(g, fr0, lh, (r0 + W / 2 - T) / 2, iz, Math.PI, lm);
  if (plan) for (let k = 1; k < plan.n; k++) { const y0 = k * WALL_H + 0.02, h2 = WALL_H - 0.26; lining(g, W - 2 * T, h2, 0, -D / 2 + T + 0.02, 0, lm, y0); lining(g, D - 2 * T, h2, -ix, 0, Math.PI / 2, lm, y0); lining(g, D - 2 * T, h2, ix, 0, -Math.PI / 2, lm, y0); lining(g, W - 2 * T, h2, 0, iz, Math.PI, lm, y0); }
  if (ceilH - 2.72 > 0.1) { const lh2 = ceilH - 2.72, lt = new THREE.Mesh(new THREE.PlaneGeometry(dw + 0.02, lh2), lm); lt.position.set(door, 2.62 + lh2 / 2, iz); lt.rotation.y = Math.PI; g.add(lt); }   // inside of the lintel
  // 3D window sills on the front (matching the painted windows), flower boxes on homes, a few 90s satellite dishes
  { const f = FACADES[def.wall] || FACADES.tan, n = f.wins;
    if (n && f.kind !== 'curtain' && !def.large) {
      const wwp = f.kind === 'logs' ? 16 : n === 1 ? 44 : (f.kind === 'tudor' ? 14 : 18), ww = wwp / 16, xs = (n === 2 ? (f.kind === 'tudor' ? [9, 41] : [7, 39]) : [Math.round((64 - wwp) / 2)]).map((x) => x / 16 + ww / 2);
      const homey2 = def.cat === 'res' && !rustic0(def), flowers = [0xd93a6a, 0xf1c40f, 0xe8e8f0, 0xb03ad9, 0xff7a2a], fz2 = D / 2 + 0.02, floors = Math.max(1, def.floors || 1);
      for (const [s0, s1] of [[l0, l1], [r0, r1]]) for (let fl = 0; fl < floors; fl++) for (let k = 0; k * 4 < W; k++) for (const xc of xs) {
        const cx2 = -W / 2 + k * 4 + xc; if (cx2 - ww / 2 < s0 + 0.05 || cx2 + ww / 2 > s1 - 0.05) continue; const y0 = fl * WALL_H + 0.84;
        box(g, ww + 0.25, 0.08, 0.22, 0xe8e2d2, cx2, y0 - 0.06, fz2 + 0.08);
        if (homey2 && fl === 0 && rnd() < 0.8) { box(g, ww * 0.85, 0.22, 0.26, 0x6a4a2a, cx2, y0 + 0.02, fz2 + 0.15); for (let i = 0; i < 5; i++) box(g, 0.13, 0.13, 0.13, flowers[(uid + i + k) % flowers.length], cx2 - ww * 0.34 + i * ww * 0.17, y0 + 0.24, fz2 + 0.15 + (i % 2 ? 0.05 : -0.05)); box(g, ww * 0.8, 0.08, 0.2, 0x3a7a3a, cx2, y0 + 0.22, fz2 + 0.15); }
      }
    }
    if (era >= 2 && (def.wall === 'brick' || def.wall === 'tan' || def.wall === 'grey') && def.cat === 'res' && rnd() < 0.45) { const sx = W / 2 - 0.6, sy = Math.min(H - 0.5, 4.6); box(g, 0.06, 0.06, 0.4, 0x666666, sx, sy, D / 2 + 0.2); const dish = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.2, 0.08, 10), stdMat(0xd8d8d0)); dish.rotation.x = Math.PI / 2 - 0.4; dish.rotation.z = 0.3; dish.position.set(sx, sy, D / 2 + 0.44); g.add(dish); }
    if (era >= 2 && !rustic0(def) && rnd() < 0.5) { box(g, 0.42, 0.42, 0.14, [0x2a5ab0, 0xe8c020, 0xc0392b][uid % 3], -W / 2 + 0.7, Math.min(H - 0.7, 2.7), D / 2 + 0.06); box(g, 0.3, 0.08, 0.15, 0xeeeeee, -W / 2 + 0.7, Math.min(H - 0.7, 2.7) + 0.3, D / 2 + 0.07); }   // burglar alarm box
    // downpipe on the front corner
    if (!rustic0(def)) box(g, 0.1, H, 0.1, 0x2a2d33, W / 2 - 0.12, 0, D / 2 + 0.08);
  }
  // front doors on hinges: shut until somebody walks up, then they swing outwards (never into the furniture)
  const rustic = RUSTIC.includes(def.wall), upvc = era >= 2 && !rustic && def.cat === 'res' && uid % 3 !== 0, dkey = upvc ? null : rustic ? 'wall_planks' : (uid % 2 ? 'door_green' : 'door_blue'), dcol = upvc ? 0xeeeee8 : rustic ? 0x7a5230 : [0x4a7a50, 0x3f6fae, 0x8a2a2a, 0x2a2a2a, 0xd9c26a][uid % 5];
  const shell = shellModel(def.id), single = def.w === 1 || !!shell, dmat = texMat(dkey, dcol, 1, 1), lw = single ? dw - 0.06 : dw / 2 - 0.03, doors = [];
  for (const side of single ? [-1] : [-1, 1]) {
    const pivot = new THREE.Group(); pivot.userData.keep = true; pivot.position.set(door + side * (dw / 2 - 0.02), 0.15, fz + T / 2 - 0.04); g.add(pivot);
    const leaf = new THREE.Mesh(new THREE.BoxGeometry(lw, 2.42, 0.07), dmat); leaf.position.set(-side * lw / 2, 1.21, 0); leaf.castShadow = true; pivot.add(leaf);
    const pane = new THREE.Mesh(new THREE.BoxGeometry(lw * 0.5, 0.5, 0.08), stdMat(0xa8cfe4)); pane.position.set(-side * lw / 2, 1.85, 0); pivot.add(pane);
    const knob = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.07, 0.14), stdMat(0xd9b34a, { metalness: 0.6, roughness: 0.3 })); knob.position.set(-side * (lw - 0.14), 1.05, 0); pivot.add(knob);
    if (!rustic && single) { const lb = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.04, 0.09), stdMat(0xd9b34a, { metalness: 0.6 })); lb.position.set(-side * lw / 2, 1.4, 0); pivot.add(lb); }   // letterbox
    colorize(pivot); mergeByMaterial(pivot); doors.push({ pivot, open: side < 0 ? -1.45 : 1.45 });   // each door leaf: one or two draws
  }
  if (def.cat === 'res' && !rustic) {
    const bx0 = door + dw / 2 + 0.75 > W / 2 - 0.4 ? door - dw / 2 - 0.75 : door + dw / 2 + 0.75, bin = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.27, 0.8, 10), stdMat(0x8a9096, { metalness: 0.4, roughness: 0.5 })); bin.position.set(bx0, 0.4, D / 2 + 0.45); bin.castShadow = true; g.add(bin);
    const lid = new THREE.Mesh(new THREE.CylinderGeometry(0.33, 0.33, 0.06, 10), stdMat(0x7a8086, { metalness: 0.4 })); lid.position.set(bx0, 0.83, D / 2 + 0.45); g.add(lid);
    if (uid % 2) for (let i = 0; i < 2; i++) { const mb = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, 0.22, 6), stdMat(0xf6f6f2)); mb.position.set(door + dw / 2 - 0.25 - i * 0.14, 0.25, D / 2 + 0.45); g.add(mb); const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.03, 6), stdMat(0xc0c8d0, { metalness: 0.7 })); cap.position.set(door + dw / 2 - 0.25 - i * 0.14, 0.37, D / 2 + 0.45); g.add(cap); }
  }
  if (def.id === 'tavern') {   // swinging pub sign on a bracket
    const sx = W / 2 - 0.4; box(g, 0.1, 0.1, 1.3, 0x1a1a1a, sx, 3.6, D / 2 + 0.6); const board = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 1.3), new THREE.MeshBasicMaterial({ map: pubSignTexture(), side: THREE.DoubleSide })); board.rotation.y = Math.PI / 2; board.position.set(sx, 2.85, D / 2 + 1.0); g.add(board);
    for (const hx of [-1.6, 1.6]) { const bk = new THREE.Mesh(new THREE.SphereGeometry(0.3, 8, 6), stdMat(0x3a7a3a)); bk.position.set(door + hx, 2.5, D / 2 + 0.4); g.add(bk); for (let i = 0; i < 5; i++) box(g, 0.12, 0.12, 0.12, [0xd93a6a, 0xf1c40f, 0xff7a2a][i % 3], door + hx + Math.cos(i) * 0.25, 2.45 + (i % 2) * 0.12, D / 2 + 0.4 + Math.sin(i) * 0.25); }
    beerGarden(g, W, D);
  }
  // door step and a little lamp over the door
  box(g, dw + 0.6, 0.16, 0.6, 0x8d8a82, door, -0.02, D / 2 + 0.3);
  if (!def.shopping && !def.dining) { const lamp = era >= 1 ? box(g, 0.22, 0.3, 0.22, 0xfff0b0, door + dw / 2 + 0.45, 2.3, D / 2 + 0.12, { emissive: 0xffd080, emissiveIntensity: 0.9 }) : box(g, 0.16, 0.24, 0.16, 0xffb050, door + dw / 2 + 0.45, 2.3, D / 2 + 0.12, { emissive: 0xff9a30, emissiveIntensity: 0.6 }); lamp.castShadow = false; }
  // a proper shopfront either side of the door: stallriser, a big display window (small panes in the older ages)
  // with goods on show behind the glass, and a painted frame
  if ((def.shopping || def.dining) && !def.special && W >= 4) {
    const frame = { 0: 0x3a2a1a, 1: 0x2a3a2a, 2: 0x1a2a4a }[era] ?? 0x2a2a2e, z = D / 2 + 0.04;
    for (const [a, b] of [[-W / 2 + 0.35, door - dw / 2 - 0.25], [door + dw / 2 + 0.25, W / 2 - 0.35]]) {
      const w = b - a; if (w < 0.9) continue; const cx = (a + b) / 2;
      box(g, w, 0.55, 0.14, frame, cx, 0, z); box(g, w, 0.08, 0.16, frame, cx, 2.15, z);
      const pane = new THREE.Mesh(new THREE.PlaneGeometry(w - 0.1, 1.55), glassMaterial()); pane.position.set(cx, 1.35, z + 0.03); g.add(pane);
      const n = era < 2 ? Math.max(2, Math.round(w / 0.45)) : Math.max(1, Math.round(w / 1.6)); for (let i = 1; i < n; i++) box(g, 0.05, 1.55, 0.06, frame, a + i * w / n, 0.57, z + 0.02);
      if (era < 2) box(g, w, 0.05, 0.06, frame, cx, 1.35, z + 0.02);
      box(g, w - 0.2, 0.06, 0.5, 0xd8d0c0, cx, 0.6, z - 0.32);   // the display shelf
      const C = [0xd8342c, 0xf2c94c, 0x2a7ab0, 0x3a9a54, 0xe07fa0, 0xf28a2a, 0xe8e2d0];
      for (let i = 0; i < Math.floor(w / 0.5); i++) box(g, 0.28, 0.2 + ((i * 7 + uid) % 3) * 0.12, 0.22, C[(i + uid) % C.length], a + 0.35 + i * 0.5, 0.66, z - 0.3);
    }
  }
  // striped shop awning over the door
  if (def.shopping || def.dining) {
    const cols2 = { chippy: [0x2a6aa8, 0xffffff], bakery: [0xd98a3a, 0xf4ecd9], newsagent: [0x2a7a3a, 0xf4ecd9], video: [0x2a3a8a, 0xf1c40f], bookies: [0x2a6a3a, 0xf4ecd9], tavern: [0x7a2a2a, 0xe8d8a8] }[def.id] || [0xc0392b, 0xf4ecd9];
    // short and steep, tucked under the sign, so it shades the door without hiding the shop front (or the sign) from above
    const aw = Math.min(W - 0.6, dw + 0.9), n = 6;
    for (let i = 0; i < n; i++) { const m = box(g, aw / n, 0.06, 0.7, cols2[i % 2], door - aw / 2 + (i + 0.5) * aw / n, 2.42, D / 2 + 0.3); m.rotation.x = 0.55; }
  }
  // sign above the door
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 0.65), new THREE.MeshBasicMaterial({ map: signTexture(def.name) }));
  sign.position.set(door, Math.min(3.05, H - 0.4), D / 2 + 0.02); g.add(sign);
  // roof
  roof.position.y = H;
  const rc = def.roofColor || 0x666666;
  if (def.roof === 'church') {
    const p = new THREE.Mesh(prism(W + 0.6, 3.6, D + 0.6), roofMaterial(rc, 'slate')); p.castShadow = true; roof.add(p);
    const tw = 3.2, tx = -W / 2 + tw / 2 + 0.2, tz = D / 2 - tw / 2 - 0.2, sm = facadeMaterial('stone');
    const tower = new THREE.Mesh(wallGeo(tw, 7, tw), sm); tower.position.set(tx, 3.5, tz); tower.castShadow = true; roof.add(tower);
    for (const [ox, oz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) box(roof, 0.5, 0.7, 0.5, 0x8a867c, tx + ox * (tw / 2 - 0.25), 7, tz + oz * (tw / 2 - 0.25));
    box(roof, 1.0, 1.5, 0.08, 0x1a1a1a, tx, 4.6, tz + tw / 2 + 0.01);                       // belfry opening
    const clock = new THREE.Mesh(new THREE.CylinderGeometry(0.6, 0.6, 0.08, 16), stdMat(0xf4f0e0, { emissive: 0xfff0c0, emissiveIntensity: 0.3 })); clock.rotation.x = Math.PI / 2; clock.position.set(tx, 2.6, tz + tw / 2 + 0.05); roof.add(clock);
    box(roof, 0.06, 0.45, 0.04, 0x1a1a1a, tx, 2.6, tz + tw / 2 + 0.1); box(roof, 0.35, 0.06, 0.04, 0x1a1a1a, tx + 0.15, 2.6, tz + tw / 2 + 0.1);
    const sp = new THREE.Mesh(new THREE.ConeGeometry(tw * 0.62, 5.5, 4), roofMaterial(0x3a424c, 'slate')); sp.rotation.y = Math.PI / 4; sp.position.set(tx, 7 + 2.75, tz); sp.castShadow = true; roof.add(sp);
    box(roof, 0.12, 1.2, 0.12, 0xd8c070, tx, 12.4, tz); box(roof, 0.6, 0.12, 0.12, 0xd8c070, tx, 12.9, tz);
    // stained glass on the front gable
    const sg = new THREE.Mesh(new THREE.CircleGeometry(1.0, 12), new THREE.MeshStandardMaterial({ color: 0x8a4ab8, emissive: 0x5a2a88, emissiveIntensity: 0.6 })); sg.position.set(W * 0.18, 1.3, D / 2 + 0.33); roof.add(sg);
  } else if (def.roof === 'gable' || def.roof === 'thatch') {
    const thatch = def.roof === 'thatch', alongZ = D >= W, ov0 = thatch ? 1.5 : 0.9, ovX = Math.min(ov0, Math.max(0.06, 2 * (mx - 0.12))), ovZ = Math.min(ov0, Math.max(0.06, 2 * (mz - 0.12))), ov = alongZ ? ovX : ovZ, ovL = alongZ ? ovZ : ovX, rh = thatch ? 1.5 + Math.min(W, D) * 0.34 : 1.0 + Math.min(W, D) * 0.28;
    const kind = thatch ? 'thatch' : (rc < 0x555566 ? 'slate' : 'tiles');
    const fz = Math.max(0, (ov0 - ovZ) / 2), sz0 = fz / 2;   // the front faces the road, not a neighbour: it keeps its eaves
    const p = new THREE.Mesh(prism(alongZ ? W + ov : D + ov + fz, rh, alongZ ? D + ovL + fz : W + ovL), roofMaterial(rc, kind));
    if (!alongZ) p.rotation.y = Math.PI / 2; p.position.z = sz0; p.castShadow = true; roof.add(p);
    if (thatch) { const ridge = new THREE.Mesh(new THREE.BoxGeometry(alongZ ? 0.25 : W + ovL, 0.22, alongZ ? D + ovL + fz : 0.25), stdMat(shadeHex(rc, 0.8))); ridge.position.set(0, rh, sz0); roof.add(ridge); }
    else if (def.id !== 'cottage' || true) { box(roof, 0.6, 1.8, 0.6, 0x7a4a3a, W * 0.2, 0.5, -D * 0.12); for (const cx of [-0.13, 0.13]) box(roof, 0.16, 0.32, 0.16, 0xb0603a, W * 0.2 + cx, 2.3, -D * 0.12); if (era >= 1 && def.cat === 'res' && (uid % 3)) { box(roof, 0.05, 1.4, 0.05, 0x333333, W * 0.2 + 0.4, 1.6, -D * 0.12); box(roof, 1.0, 0.04, 0.04, 0x333333, W * 0.2 + 0.4, 2.8, -D * 0.12); box(roof, 0.04, 0.04, 0.6, 0x333333, W * 0.2 + 0.4, 2.6, -D * 0.12); } }
    if (!thatch) { const ew = alongZ ? W + ov : D + ov + fz, el = alongZ ? D + ovL + fz : W + ovL; for (const sd of [-1, 1]) { if (alongZ) box(roof, 0.14, 0.14, el, 0x2a2d33, sd * ew / 2, -0.08, sz0); else box(roof, el, 0.14, 0.14, 0x2a2d33, 0, -0.08, sd * ew / 2 + sz0); } }   // gutters
  } else {
    if (!(plan && plan.roof)) box(roof, W + 0.3, 0.35, D + 0.3, rc, 0, 0, 0);
    else { const gm = roofMaterial(rc, 'gravel'); for (const [sx, sz, x, z] of [[W - 0.1, T, 0, D / 2 - T / 2 - 0.03], [W - 0.1, T, 0, -D / 2 + T / 2 + 0.03], [T, D - 0.1, W / 2 - T / 2 - 0.03, 0], [T, D - 0.1, -W / 2 + T / 2 + 0.03, 0]]) { const e = new THREE.Mesh(unit, gm); e.scale.set(sx, 0.2, sz); e.position.set(x, -0.08, z); e.receiveShadow = true; roof.add(e); } }   // the gravel carries on over the wall tops to the parapet (no gap)
    const ex = Math.min(0.25, Math.max(0, mx - 0.03)), ez = Math.min(0.25, Math.max(0, mz - 0.03)), px = 0.05 + ex, pz = 0.05 + ez;   // parapets: no further out than the plot allows
    for (const [x, z, sx, sz] of [[0, D / 2 - 0.05 + pz / 2, W + 2 * ex, pz], [0, -D / 2 + 0.05 - pz / 2, W + 2 * ex, pz], [W / 2 - 0.05 + px / 2, 0, px, D + 2 * ez], [-W / 2 + 0.05 - px / 2, 0, px, D + 2 * ez]]) box(roof, sx, 0.55, sz, 0xf2f2ee, x, 0.35, z);
    const props = def.roof === 'flatac' || def.roof === 'flat' ? 2 + Math.floor(rnd() * 3) : 0;
    const busy = plan && plan.roof ? slabHoles(plan, plan.n).map((r) => [r[0] - 1.4, r[1] + 1.4, r[2] - 1.4, r[3] + 1.4]) : [];
    for (let i = 0; i < props; i++) { const s = 0.7 + rnd() * 1.1, hh = 0.7 + rnd() * 0.6; let x = 0, z = 0, ok = false; for (let t = 0; t < 8 && !ok; t++) { x = (rnd() - 0.5) * (W - 3); z = (rnd() - 0.5) * (D - 3); ok = !busy.some((r) => x + s * 0.7 > r[0] && x - s * 0.7 < r[1] && z + s / 2 > r[2] && z - s / 2 < r[3]); } if (!ok) continue; box(roof, s * 1.4, hh, s, 0xaeb4bc, x, plan && plan.roof ? 0.05 : 0.35, z); roofCols.push([x - s * 0.7, x + s * 0.7, z - s / 2, z + s / 2]); busy.push([x - s, x + s, z - s, z + s]); }
    if (def.roof === 'dome') roofCols.push([-3.5, 3.5, -3.5, 3.5]);
    if (def.roof === 'dome') {
      const drum = new THREE.Mesh(new THREE.CylinderGeometry(3.2, 3.4, 1.6, 12), stdMat(0xe6dfcc)); drum.position.y = 1.1; drum.castShadow = true; roof.add(drum);
      const dome = new THREE.Mesh(new THREE.SphereGeometry(3.1, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2), stdMat(rc, { roughness: 0.5, metalness: 0.2 })); dome.position.y = 1.9; dome.castShadow = true; roof.add(dome);
      box(roof, 0.25, 1.4, 0.25, 0xd8c070, 0, 4.9, 0);
    }
    if (def.roof === 'plant') {
      for (const x of [-3.2, 3.2]) { for (let k = 0; k < 4; k++) box(roof, 1.5 - k * 0.1, 1.6, 1.5 - k * 0.1, k % 2 ? 0xf2f2ee : 0xc0392b, x, 0.35 + k * 1.6, -1.5); }
      const tank = new THREE.Mesh(new THREE.CylinderGeometry(1.8, 1.8, 2.4, 10), stdMat(0xaeb4bc)); tank.position.set(0, 1.5, 2.2); tank.castShadow = true; roof.add(tank);
    }
    if (def.roof === 'factory') {
      for (let i = 0; i < 4; i++) { const s = new THREE.Mesh(prism(2.8, 1.4, D - 0.6), stdMat(0x7a8088, { side: THREE.DoubleSide, flatShading: true })); s.position.set(-W / 2 + 2.4 + i * 3.6, 0.3, 0); s.castShadow = true; roof.add(s); }
      for (let k = 0; k < 5; k++) box(roof, 1.0, 1.6, 1.0, k % 2 ? 0xf2f2ee : 0xb23a2d, W / 2 - 1.5, 0.35 + k * 1.6, -D / 2 + 1.5);
    }
    if (def.roof === 'tank') {
      for (const [x, z] of [[-0.9, -0.9], [0.9, -0.9], [-0.9, 0.9], [0.9, 0.9]]) box(roof, 0.18, 9, 0.18, 0x666d77, x, 0.2, z);
      const tank = new THREE.Mesh(new THREE.CylinderGeometry(2.0, 2.0, 3, 12), stdMat(0xd7dde4, { metalness: 0.2 })); tank.position.y = 10.6; tank.castShadow = true; roof.add(tank);
      const cap = new THREE.Mesh(new THREE.ConeGeometry(2.1, 1.1, 12), stdMat(0x445566)); cap.position.y = 12.7; roof.add(cap);
    }
    if (def.roof === 'spire') { roofCols.push([-(W - 6) / 2, (W - 6) / 2, -(D - 6) / 2, (D - 6) / 2]); box(roof, W - 6, 3, D - 6, 0x39434d, 0, 0.05, 0); box(roof, 0.35, 10, 0.35, 0xcccccc, 0, 3.3, 0); box(roof, 0.5, 0.5, 0.5, 0xff3030, 0, 13.3, 0, { emissive: 0xff2020, emissiveIntensity: 1.2 }); }
  }
  if (shell) useShell(g, roof, cols, shell, { W, D, T, H, keep: [mat, lm] });
  const curtains = def.cat === 'res' && !def.large && !shell ? buildCurtains(def, g, uid, T, door, dw) : null;
  { const sx = mx < 0.06 ? (W - 0.14) / W : 1, sz = mz < 0.06 ? (D - 0.14) / D : 1; if (sx !== 1 || sz !== 1) { g.scale.set(sx, 1, sz); roof.scale.set(sx, 1, sz); } }   // fills its plot exactly: pull the walls in a touch so they don't fight next door's
  ALIGN = null;
  const levels = plan ? buildLevels(def, plan, g, cols, roof) : null;
  return { group: g, roof, colliders: cols, height: H, doors, plan, curtains, levels: levels && levels.groups, liftCab: levels && levels.cab, roofDoor: levels && levels.roofDoor, roofCols };
}

/** Floors, ceilings, staircases and the lift shaft of a building with storeys you can walk up to (see Levels.js). */
function buildLevels(def, p, g, cols, roof) {
  const W = p.W, D = p.D, T = WALL_T, groups = [null], look = INTERIOR[def.layout] || (['house', 'apartments'].includes(def.layout) ? ['floor_wood', 0xa6825a] : ['floor_wood', 0xa6825a]);
  const fmat = texMat(look[0], look[1], W / 4, D / 4), concrete = ['office', 'lobby', 'clinic', 'police', 'apartments'].includes(def.layout), stepC = concrete ? 0x8d9096 : 0x7a5230, railC = concrete ? 0x5a5e66 : 0x4a3018;
  const top = p.roof ? p.n : p.n;   // a ceiling over the top storey too (with the hatch when there's a roof)
  for (let k = 1; k <= top; k++) {
    const lg = new THREE.Group(); lg.userData.keep = true; g.add(lg); groups.push(lg);
    const y = k * WALL_H, holes = slabHoles(p, k);
    for (const [x0, x1, z0, z1] of rectMinus([-W / 2 + T, W / 2 - T, -D / 2 + T, D / 2 - T], holes)) {
      const w = x1 - x0, d = z1 - z0, cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
      if (k < p.n || p.roof) { const f = new THREE.Mesh(unit, k < p.n ? fmat : roofMaterial(def.roofColor || 0x666666, 'gravel')); f.scale.set(w, 0.2, d); f.position.set(cx, y - 0.08, cz); f.receiveShadow = true; lg.add(f); }
      box(lg, w, 0.05, d, 0xe8e4da, cx, y - 0.24, cz, { emissive: 0xfff2d0, emissiveIntensity: 0.55 });
    }
    // a little rail round the stairwell on the floor above it
    for (const r of holes) if (!p.lift || r[0] !== p.lift.x0) { const ax = p.stair.ax; if (ax === 'x') { box(lg, r[1] - r[0], 0.08, 0.08, railC, (r[0] + r[1]) / 2, y + 0.9, p.stair.wallAt ? r[2] : r[3]); } else box(lg, 0.08, 0.08, r[3] - r[2], railC, p.stair.wallAt ? r[0] : r[1], y + 0.9, (r[2] + r[3]) / 2); }
  }
  // staircases: one flight per storey, zig-zagging in two lanes
  if (p.stair) {
    const st = p.stair, N = 16, L = st.s1 - st.s0, run = L / N;
    for (const ln of st.lanes) for (const k of ln.flights) {
      const tg = groups[k] || g, base = k * WALL_H, cw = ln.c1 - ln.c0, cc = (ln.c0 + ln.c1) / 2;
      for (let i = 0; i < N; i++) {
        const s = st.s0 + (i + 0.5) * run, h = flightH(st, k, s) + WALL_H / N / 2, th = k === 0 ? h : 0.4, y0 = h - th;
        const [x, z, sx, sz] = st.ax === 'x' ? [s, cc, run + 0.01, cw - 0.04] : [cc, s, cw - 0.04, run + 0.01];
        box(tg, sx, th, sz, i % 2 ? stepC : shade(stepC), x, Math.max(0, y0), z);
      }
      // banister on the open side, posts at the ends
      const open = st.wallAt ? ln.c0 : ln.c1, len = Math.hypot(L, WALL_H), ang = Math.atan2(WALL_H, L), up = (k % 2 === 0) === (st.dir > 0);
      const rail = box(tg, st.ax === 'x' ? len : 0.07, 0.07, st.ax === 'x' ? 0.07 : len, railC, st.ax === 'x' ? (st.s0 + st.s1) / 2 : open, base + WALL_H / 2 + 0.9 - 0.035, st.ax === 'x' ? open : (st.s0 + st.s1) / 2);
      if (st.ax === 'x') rail.rotation.z = up ? ang : -ang; else rail.rotation.x = up ? -ang : ang;
      for (const e of [st.s0, st.s1]) { const hy = flightH(st, k, e); box(tg, 0.1, 1.0, 0.1, railC, st.ax === 'x' ? e : open, hy, st.ax === 'x' ? open : e); }
    }
  }
  // the lift: a shaft in the back corner with a door on every floor, a cab that rides up and down, and a hut on the roof
  let cab = null;
  if (p.lift) {
    const L = p.lift, Ht = p.H + (p.roof ? 2.6 : 0), sm = stdMat(0xb8bcc2), dg = 1.2;
    const part = (cx, cz, sx, sz) => { const m = new THREE.Mesh(unit, sm); m.scale.set(sx, Ht, sz); m.position.set(cx, Ht / 2, cz); m.castShadow = true; m.receiveShadow = true; g.add(m); cols.push({ cx, cz, sx, sz }); };
    part(L.x0 - 0.075, (L.z0 + L.z1) / 2, 0.15, L.z1 - L.z0 + 0.15);
    const fz = L.z1 + 0.075, a0 = L.x0 - 0.15, a1 = L.door - dg / 2, b0 = L.door + dg / 2, b1 = L.x1;
    part((a0 + a1) / 2, fz, a1 - a0, 0.15); part((b0 + b1) / 2, fz, b1 - b0, 0.15);
    for (let k = 0; k <= p.n; k++) { if (k === p.n && !p.roof) break; const y = k * WALL_H; box(g, dg, 0.3, 0.2, 0x3a3e46, L.door, y + 2.35, fz); box(g, 0.25, 0.35, 0.05, 0x22262c, b0 + 0.3, y + 1.2, fz + 0.1, { emissive: 0xffb030, emissiveIntensity: 0.6 }); }
    if (p.roof) box(roof, L.x1 - L.x0 + 0.3, 0.2, L.z1 - L.z0 + 0.3, 0x6b7078, (L.x0 + L.x1) / 2, 2.6, (L.z0 + L.z1) / 2);
    cab = new THREE.Group(); cab.userData.keep = true; const cw = L.x1 - L.x0 - 0.1, cd = L.z1 - L.z0 - 0.1;
    box(cab, cw, 0.12, cd, 0x5a4a3a, 0, 0, 0); box(cab, cw, 2.5, 0.06, 0x9aa0a8, 0, 0.12, -cd / 2); box(cab, 0.06, 2.5, cd, 0x9aa0a8, -cw / 2, 0.12, 0); box(cab, 0.06, 2.5, cd, 0x9aa0a8, cw / 2, 0.12, 0);
    box(cab, cw, 0.06, cd, 0xf0ead8, 0, 2.62, 0, { emissive: 0xfff0c0, emissiveIntensity: 0.7 }); box(cab, 0.5, 0.06, 0.05, 0xd9b34a, 0, 1.0, -cd / 2 + 0.06, { metalness: 0.6 });
    cab.position.set((L.x0 + L.x1) / 2, 0.08, (L.z0 + L.z1) / 2); g.add(cab);
  }
  // the stair hut on the roof, with a door that swings open
  let roofDoor = null;
  if (p.hut) {
    const hg = groups[p.n], [x0, x1, z0, z1] = p.hut.rect, y = p.H, hh = 2.5, d = p.hut.door, wc = 0x9a968c, alongX = d.ax === 'x';
    const wall = (cx, cz, sx, sz) => box(hg, sx, hh, sz, wc, cx, y, cz);
    if (alongX) { wall((x0 + x1) / 2, z0, x1 - x0, 0.15); wall((x0 + x1) / 2, z1, x1 - x0, 0.15); const back = d.x > (x0 + x1) / 2 ? x0 : x1; wall(back, (z0 + z1) / 2, 0.15, z1 - z0); for (const [a, b] of [[z0, d.z - 0.55], [d.z + 0.55, z1]]) if (b - a > 0.05) wall(d.x, (a + b) / 2, 0.15, b - a); }
    else { wall(x0, (z0 + z1) / 2, 0.15, z1 - z0); wall(x1, (z0 + z1) / 2, 0.15, z1 - z0); const back = d.z > (z0 + z1) / 2 ? z0 : z1; wall((x0 + x1) / 2, back, x1 - x0, 0.15); for (const [a, b] of [[x0, d.x - 0.55], [d.x + 0.55, x1]]) if (b - a > 0.05) wall((a + b) / 2, d.z, b - a, 0.15); }
    box(hg, x1 - x0 + 0.3, 0.15, z1 - z0 + 0.3, 0x6b7078, (x0 + x1) / 2, y + hh, (z0 + z1) / 2); box(hg, alongX ? 0.18 : 1.2, 0.25, alongX ? 1.2 : 0.18, 0x3a3d44, d.x, y + 2.15, d.z);
    const pivot = new THREE.Group(); pivot.userData.keep = true; pivot.position.set(alongX ? d.x : d.x - 0.5, y, alongX ? d.z - 0.5 : d.z); hg.add(pivot);
    const leaf = new THREE.Mesh(new THREE.BoxGeometry(alongX ? 0.06 : 1.0, 2.05, alongX ? 1.0 : 0.06), stdMat(0x3a5a7a)); leaf.position.set(alongX ? 0 : 0.5, 1.03, alongX ? 0.5 : 0); pivot.add(leaf);
    const sign = new THREE.Mesh(new THREE.BoxGeometry(alongX ? 0.04 : 0.5, 0.2, alongX ? 0.5 : 0.04), stdMat(0x2a8a3a, { emissive: 0x2a8a3a, emissiveIntensity: 0.8 })); sign.position.set(alongX ? 0 : 0.5, 2.3, alongX ? 0.5 : 0); pivot.add(sign);
    roofDoor = { pivot, open: 0, x: d.x, z: d.z, y };
  }
  for (const lg of groups) if (lg) { colorize(lg); mergeByMaterial(lg); }
  return { groups, cab, roofDoor };
}
const shade = (hex) => { const c = new THREE.Color(hex); c.multiplyScalar(0.85); return c.getHex(); };
/** A rectangle with holes cut out, as a list of rectangles (grid split along every hole edge). */
function rectMinus(R, holes) {
  const hs = holes.map((h) => [Math.max(R[0], h[0]), Math.min(R[1], h[1]), Math.max(R[2], h[2]), Math.min(R[3], h[3])]).filter((h) => h[0] < h[1] && h[2] < h[3]);
  const xs = [...new Set([R[0], R[1], ...hs.flatMap((h) => [h[0], h[1]])])].sort((a, b) => a - b), zs = [...new Set([R[2], R[3], ...hs.flatMap((h) => [h[2], h[3]])])].sort((a, b) => a - b), out = [];
  for (let j = 0; j < zs.length - 1; j++) { let run = null; for (let i = 0; i < xs.length - 1; i++) {
    const cx = (xs[i] + xs[i + 1]) / 2, cz = (zs[j] + zs[j + 1]) / 2, solid = !hs.some((h) => cx > h[0] && cx < h[1] && cz > h[2] && cz < h[3]);
    if (solid) { if (run) run[1] = xs[i + 1]; else run = [xs[i], xs[i + 1], zs[j], zs[j + 1]]; } else if (run) { out.push(run); run = null; }
  } if (run) out.push(run); }
  return out;
}

/** The Lock-Up: a round stone tower with a little domed roof and slit windows, like the one on the Everton badge. */
/** A 1970s multi-storey car park: bare concrete decks on columns, a ramp, and a space for every car (ext.spaces). */
function buildCarPark(def) {
  const g = new THREE.Group(), roof = new THREE.Group(), cols = [], W = def.w * UNIT, D = def.d * UNIT, decks = 3, Hh = 2.8, spaces = [];
  for (let k = 0; k < decks; k++) { const y = k * Hh; box(g, W, 0.3, D, 0x9a9890, 0, y - 0.15, 0); if (k) for (const sx of [-1, 1]) box(g, W, 0.9, 0.2, 0x8a8880, 0, y + 0.15, sx * (D / 2 - 0.1)); }
  box(g, W, 0.3, D, 0x8a8880, 0, decks * Hh - 0.15, 0);   // the top deck (open to the sky)
  for (const x of [-W / 2 + 0.3, 0, W / 2 - 0.3]) for (const z of [-D / 2 + 0.3, D / 2 - 0.3]) box(g, 0.4, decks * Hh, 0.4, 0xa8a69e, x, 0, z);
  const ramp = box(g, 3.2, 0.25, Hh * 2.2, 0x7a7870, W / 2 - 1.8, Hh / 2, 0); ramp.rotation.x = -Math.atan2(Hh, Hh * 2.2);
  for (let k = 0; k <= decks; k++) for (let i = 0; i < 4; i++) { const x = -W / 2 + 1.6 + i * 2.6; if (x > W / 2 - 3.6) continue; for (const sz of [-1, 1]) { const z = sz * (D / 2 - 2.6); spaces.push({ x, z, y: k * Hh, h: sz > 0 ? Math.PI : 0 }); for (const dx of [-1.2, 1.2]) box(g, 0.08, 0.02, 4.4, 0xf2f2f2, x + dx, k * Hh + 0.01, z); } }
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 0.8), new THREE.MeshBasicMaterial({ map: signTexture('P  CAR PARK', '#1a3a8a') })); sign.position.set(0, Hh + 1.2, D / 2 + 0.05); g.add(sign);
  for (const [x, z] of [[-W / 2 + 0.3, -D / 2 + 0.3], [W / 2 - 0.3, -D / 2 + 0.3], [-W / 2 + 0.3, D / 2 - 0.3], [W / 2 - 0.3, D / 2 - 0.3]]) cols.push({ cx: x, cz: z, sx: 0.5, sz: 0.5, h: decks * Hh });
  return { group: g, roof, colliders: cols, height: decks * Hh, doors: [], spaces };
}
function buildLockup(def) {
  const g = new THREE.Group(), roof = new THREE.Group(), cols = [], W = def.w * UNIT, R = W * 0.36, sm = stdMat(0xb4ae9e);
  box(g, W + 0.4, 0.25, W + 0.4, 0x9a9b9c, 0, -0.15, 0);
  const tower = new THREE.Mesh(new THREE.CylinderGeometry(R, R * 1.05, 4.6, 14), sm); tower.position.y = 2.3; tower.castShadow = true; tower.receiveShadow = true; g.add(tower);
  for (let i = 0; i < 14; i++) { const a = i / 14 * Math.PI * 2; if (i % 2) box(g, 0.5, 0.5, 0.35, 0xa8a292, Math.cos(a) * R, 4.6, Math.sin(a) * R).rotation.y = -a; }   // battlements
  const dome = new THREE.Mesh(new THREE.SphereGeometry(R * 0.8, 12, 6, 0, Math.PI * 2, 0, Math.PI / 2), stdMat(0x5a5e66)); dome.position.y = 4.6; roof.add(dome); box(roof, 0.1, 0.8, 0.1, 0x2a2a2a, 0, 5.8, 0);
  box(g, 1.0, 2.0, 0.2, 0x3a2a1a, 0, 0, R - 0.02); box(g, 1.2, 0.2, 0.25, 0x8d8a82, 0, 2.0, R);   // a heavy door
  for (const a of [0.8, 2.4, 4.0]) box(g, 0.12, 0.6, 0.15, 0x1a1a1a, Math.cos(a) * R, 2.8, Math.sin(a) * R).rotation.y = -a;   // slit windows
  cols.push({ cx: 0, cz: 0, sx: R * 1.8, sz: R * 1.8 });
  return { group: g, roof, colliders: cols, height: 5, doors: [] };
}

/** Set by mods (render/Models.js) so buildings can be blocky models. */
let MODEL_BUILD = null; export function setModelBuilder(fn) { MODEL_BUILD = fn; }
const _adTex = [];
/** A poster for one of the (made-up) brands in data/adverts.js. */
export function adTexture(i) {
  if (_adTex[i]) return _adTex[i]; const [head, line, bg, fg] = ADS[i], c = document.createElement('canvas'); c.width = 256; c.height = 128; const x = c.getContext('2d');
  x.fillStyle = bg; x.fillRect(0, 0, 256, 128); x.fillStyle = fg; x.textAlign = 'center'; x.font = 'bold 30px Georgia, serif'; x.fillText(head, 128, 52, 240);
  x.font = '13px Georgia, serif'; const words = line.split(' '); let ln = '', y = 80; for (const w of words) { if (x.measureText(ln + w).width > 228) { x.fillText(ln.trim(), 128, y); ln = ''; y += 16; } ln += w + ' '; } x.fillText(ln.trim(), 128, y);
  x.strokeStyle = fg; x.lineWidth = 3; x.strokeRect(5, 5, 246, 118);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return (_adTex[i] = t);
}
let _pubTex = null;
/** The beer garden down the side and round the back: picnic tables under brollies, a picket fence, a sign. */
function beerGarden(g, W, D) {
  const m = 1.85, xL = -W / 2 - m / 2 - 0.05, zB = -D / 2 - m / 2 - 0.05, wood = 0x9a7048, brolly = [0xc0392b, 0x2a6ab0, 0x2a8a4a];
  const seats = g.userData.garden = [];
  const table = (x, z, rot, k) => {
    for (const sz of [-0.55, 0.55]) for (const bx of [-0.4, 0.4]) seats.push({ x: x + bx * Math.cos(rot) + sz * Math.sin(rot), z: z - bx * Math.sin(rot) + sz * Math.cos(rot), h: (sz > 0 ? Math.PI : 0) + rot });   // four to a table, facing in
    const t = new THREE.Group(); t.position.set(x, 0, z); t.rotation.y = rot; g.add(t);
    box(t, 1.5, 0.07, 0.7, wood, 0, 0.72, 0); for (const sz of [-0.55, 0.55]) box(t, 1.5, 0.06, 0.26, wood, 0, 0.42, sz);   // top and the two benches
    for (const sx of [-0.6, 0.6]) { box(t, 0.07, 0.72, 0.07, 0x7a5638, sx, 0, 0); box(t, 0.07, 0.07, 1.36, 0x7a5638, sx, 0.36, 0); }
    box(t, 0.05, 2.2, 0.05, 0xd8d8d8, 0, 0, 0); const c = new THREE.Mesh(new THREE.ConeGeometry(1.15, 0.45, 8), stdMat(brolly[k % 3], { flatShading: true })); c.position.y = 2.25; c.castShadow = true; t.add(c);
    box(t, 0.12, 0.2, 0.12, 0xf2c94c, 0.35, 0.79, 0.1); box(t, 0.12, 0.2, 0.12, 0xa86a2a, -0.3, 0.79, -0.12);   // a pint of lager and one of bitter
  };
  for (const [i, z] of [-D / 2 + 2.4, 0.4].entries()) table(xL, z, Math.PI / 2, i);
  for (const [i, x] of [-W / 2 + 2.6, 1.4].entries()) table(x, zB, 0, i + 2);
  // the picket fence round the outside edge
  const fx = -W / 2 - m, fz = -D / 2 - m;
  box(g, 0.06, 0.08, D / 2 + m + 2, 0xf2ece0, fx, 0.75, (fz + D / 2 - 1.2) / 2 + 0.6); box(g, W / 2 + m + 2.6, 0.08, 0.06, 0xf2ece0, (fx + W / 2 - 2.6) / 2 + 1.3, 0.75, fz);
  for (let z = fz; z < D / 2 - 0.6; z += 0.5) box(g, 0.08, 1.0, 0.04, 0xf2ece0, fx, 0, z);
  for (let x = fx; x < W / 2 - 1.3; x += 0.5) box(g, 0.04, 1.0, 0.08, 0xf2ece0, x, 0, fz);
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(1.3, 0.4), new THREE.MeshBasicMaterial({ map: signTexture('BEER GARDEN', '#1f3a20', '#f2e6b0') })); sign.position.set(fx - 0.06, 1.25, D / 2 - 1.4); sign.rotation.y = -Math.PI / 2; g.add(sign);
}
function pubSignTexture() {
  if (_pubTex) return _pubTex; const c = document.createElement('canvas'); c.width = 64; c.height = 80; const x = c.getContext('2d');
  x.fillStyle = '#2a1a10'; x.fillRect(0, 0, 64, 80); x.fillStyle = '#e8d8a8'; x.fillRect(3, 3, 58, 74); x.fillStyle = '#7a1a1a'; x.fillRect(5, 5, 54, 70);
  x.fillStyle = '#d4a020'; x.fillRect(16, 30, 30, 16); x.fillRect(40, 22, 12, 12); x.fillRect(18, 46, 5, 12); x.fillRect(38, 46, 5, 12); x.fillRect(10, 26, 8, 4); x.fillStyle = '#c03020'; x.fillRect(48, 26, 4, 3);   // a very heraldic lion
  x.fillStyle = '#f4e4c1'; x.font = 'bold 9px monospace'; x.textAlign = 'center'; x.fillText('THE RED', 32, 14); x.fillText('LION', 32, 72);
  const t = new THREE.CanvasTexture(c); t.magFilter = THREE.NearestFilter; t.colorSpace = THREE.SRGBColorSpace; return (_pubTex = t);
}
function buildPark(def, uid) {
  const W = def.w * UNIT, D = def.d * UNIT, rnd = mulberry32(uid * 31 + 5), g = new THREE.Group(), roof = new THREE.Group();
  const lawn = new THREE.Mesh(new THREE.BoxGeometry(W - 0.3, 0.12, D - 0.3), stdMat(def.park === 'field' ? 0x6aa64f : 0x66a74e)); lawn.position.y = 0.04; lawn.receiveShadow = true; g.add(lawn);
  const tree = (x, z, s = 1) => { box(g, 0.35 * s, 1.2 * s, 0.35 * s, 0x5a3b22, x, 0, z); const c = new THREE.Mesh(new THREE.ConeGeometry(1.4 * s, 3 * s, 6), stdMat(0x2f7a3a, { flatShading: true })); c.position.set(x, 2.4 * s, z); c.castShadow = true; g.add(c); };
  const cols = [];
  if (def.park === 'park') {
    box(g, 0.9, 0.02, D - 1, 0xcdb58a, 0, 0.1, 0);
    tree(-W / 2 + 1.4, -D / 2 + 1.4, 1.1); tree(W / 2 - 1.4, -D / 2 + 1.6, 0.9); tree(-W / 2 + 1.5, D / 2 - 1.6, 1.0); tree(W / 2 - 1.6, D / 2 - 1.4, 1.2);
    box(g, 1.8, 0.1, 0.5, 0x8a5a33, 1.4, 0.45, 0.3); box(g, 1.8, 0.45, 0.08, 0x8a5a33, 1.4, 0.5, 0.05);
  } else if (def.park === 'plaza') {
    box(g, W - 1, 0.04, D - 1, 0xc9bda3, 0, 0.1, 0);
    const basin = new THREE.Mesh(new THREE.CylinderGeometry(2.6, 2.8, 0.7, 14), stdMat(0xb9b4a8)); basin.position.y = 0.4; basin.castShadow = true; g.add(basin);
    const water = new THREE.Mesh(new THREE.CylinderGeometry(2.3, 2.3, 0.1, 14), stdMat(0x4aa3dc, { emissive: 0x1a5a99, emissiveIntensity: 0.4 })); water.position.y = 0.72; g.add(water);
    box(g, 0.5, 1.8, 0.5, 0xd6d0c0, 0, 0.7, 0); cols.push({ cx: 0, cz: 0, sx: 5.2, sz: 5.2, h: 0.9 });
    tree(-W / 2 + 1.1, -D / 2 + 1.1, 1.0); tree(W / 2 - 1.1, -D / 2 + 1.1, 1.0); tree(-W / 2 + 1.1, D / 2 - 1.1, 1.0); tree(W / 2 - 1.1, D / 2 - 1.1, 1.0);
    box(g, 2, 0.1, 0.5, 0x8a5a33, -3.8, 0.45, 0.2); box(g, 2, 0.1, 0.5, 0x8a5a33, 3.8, 0.45, 0.2);
  } else if (def.park === 'camp') {
    return buildCamp(def, g, roof, cols);
  } else if (def.park === 'well') {
    return buildWell(def, g, roof, cols);
  } else if (def.park === 'postbox') {
    return buildPostbox(def, g, roof, cols);
  } else if (def.park === 'billboard') {   // a poster hoarding on two legs; the poster changes now and then
    lawn.visible = false; box(g, 0.18, 2.4, 0.18, 0x4a4e56, -1.3, 0, 0); box(g, 0.18, 2.4, 0.18, 0x4a4e56, 1.3, 0, 0); box(g, 3.6, 1.9, 0.16, 0x2a2a2a, 0, 2.3, -0.02);
    const mat = new THREE.MeshBasicMaterial({ map: adTexture(uid % ADS.length) }), poster = new THREE.Mesh(new THREE.PlaneGeometry(3.4, 1.7), mat); poster.position.set(0, 3.25, 0.07); g.add(poster);
    const back = new THREE.Mesh(new THREE.PlaneGeometry(3.4, 1.7), mat); back.position.set(0, 3.25, -0.11); back.rotation.y = Math.PI; g.add(back);
    cols.push({ cx: 0, cz: 0, sx: 3, sz: 0.3, h: 4.2 }); let cur = -1;
    return { group: g, roof, colliders: cols, height: 4.2, update: (dt, t) => { const k = (uid + Math.floor(t / 150)) % ADS.length; if (k !== cur) { cur = k; mat.map = adTexture(k); } } };
  } else if (def.park === 'phonebox') {
    return buildPhonebox(def, g, roof, cols);
  } else if (def.park === 'busstop') {
    return buildBusStop(def, g, roof, cols);
  } else if (def.park === 'graveyard') {   // headstones in rows (more appear as people are buried), a yew, a lychgate, a dry-stone wall
    lawn.material = stdMat(0x5a8a44);
    for (const [x, z, sx, sz] of [[0, -D / 2 + 0.2, W, 0.4], [-W / 2 + 0.2, 0, 0.4, D], [W / 2 - 0.2, 0, 0.4, D], [-W / 2 + 1.6, D / 2 - 0.2, 2.8, 0.4], [W / 2 - 1.6, D / 2 - 0.2, 2.8, 0.4]]) box(g, sx, 0.8, sz, 0x8d8a82, x, 0, z);
    box(g, 0.2, 2.2, 0.2, 0x4a3018, -1.0, 0, D / 2 - 0.2); box(g, 0.2, 2.2, 0.2, 0x4a3018, 1.0, 0, D / 2 - 0.2); const lg = new THREE.Mesh(prism(2.6, 0.9, 0.9), roofMaterial(0x4a4e56, 'slate')); lg.position.set(0, 2.2, D / 2 - 0.2); lg.rotation.y = Math.PI / 2; g.add(lg);
    const yew = new THREE.Mesh(new THREE.ConeGeometry(1.6, 4.2, 7), stdMat(0x1f4a2a, { flatShading: true })); yew.position.set(W / 2 - 1.4, 2.4, -D / 2 + 1.4); yew.castShadow = true; g.add(yew); box(g, 0.4, 0.6, 0.4, 0x4a3018, W / 2 - 1.4, 0, -D / 2 + 1.4);
    const graves = new THREE.Group(); graves.userData.keep = true; g.add(graves); const stones = [];
    for (let r = 0; r < 4; r++) for (let c = 0; c < 5; c++) { const x = -W / 2 + 1.0 + c * 1.25, z = -D / 2 + 1.2 + r * 1.55; if (x > W / 2 - 2.4 && z < -D / 2 + 2.6) continue; const st = new THREE.Group(); st.position.set(x, 0, z); const cross = rnd() < 0.25;
      if (cross) { box(st, 0.12, 0.9, 0.12, 0xb8b4aa, 0, 0, 0); box(st, 0.5, 0.12, 0.12, 0xb8b4aa, 0, 0.6, 0); } else { box(st, 0.55, 0.7, 0.14, [0xa8a49a, 0x8d8a82, 0xc0bcb2][(r + c) % 3], 0, 0, 0); box(st, 0.55, 0.06, 0.16, 0x9a968c, 0, 0.7, 0); }
      box(st, 0.55, 0.08, 1.0, 0x6a7a4a, 0, 0, 0.55); st.visible = false; graves.add(st); stones.push(st); }
    return { group: g, roof, colliders: [], height: 2, everyFrame: false, update: (dt, t, stock, b) => { const n = 4 + ((b && b.buried) || 0); stones.forEach((s, i) => { s.visible = i < n; }); } };
  } else if (def.park === 'bandstand') {
    return buildBandstand(def, g, roof, cols, tree);
  } else if (def.park === 'allotment') {
    return buildAllotment(def, g, roof, cols, rnd);
  } else { // the cricket green: mown stripes, a square with the pitch and stumps, a boundary rope, a pavilion and a scoreboard
    for (let k = 0; k < 6; k++) box(g, (W - 0.4) / 6, 0.02, D - 0.4, k % 2 ? 0x74b358 : 0x649f4a, -W / 2 + 0.2 + (k + 0.5) * (W - 0.4) / 6, 0.1, 0);
    box(g, 3.2, 0.02, 9.6, 0x86b866, 0, 0.12, 0); box(g, 1.5, 0.03, 8.4, 0xcdbb84, 0, 0.13, 0);
    for (const sz of [-1, 1]) { box(g, 1.9, 0.01, 0.06, 0xffffff, 0, 0.15, sz * 3.6); box(g, 0.06, 0.01, 1.2, 0xffffff, -0.75, 0.15, sz * 4.1); box(g, 0.06, 0.01, 1.2, 0xffffff, 0.75, 0.15, sz * 4.1);
      for (const sx of [-0.11, 0, 0.11]) box(g, 0.04, 0.72, 0.04, 0xf2ead0, sx, 0.14, sz * 4.0); box(g, 0.3, 0.03, 0.04, 0xf2ead0, 0, 0.87, sz * 4.0); }
    const rope = new THREE.Mesh(new THREE.TorusGeometry(Math.min(W, D) / 2 - 0.7, 0.05, 4, 48), stdMat(0xffffff)); rope.rotation.x = Math.PI / 2; rope.position.y = 0.16; g.add(rope);
    // the pavilion: white boards, green roof, a veranda and a clock
    const px = -W / 2 + 2.0, pz = -D / 2 + 1.3; box(g, 3.2, 2.2, 1.8, 0xf2efe6, px, 0, pz); box(g, 3.6, 0.15, 2.4, 0x2a5a3a, px, 2.2, pz + 0.2); box(g, 3.2, 0.12, 0.8, 0xb59a6a, px, 0.12, pz + 1.3);
    for (const vx of [-1.5, 1.5]) box(g, 0.1, 2.1, 0.1, 0xf2efe6, px + vx, 0.1, pz + 1.65); box(g, 0.9, 1.6, 0.04, 0x3a2a1a, px, 0.2, pz + 0.91); box(g, 0.5, 0.5, 0.05, 0xf8f4e0, px, 2.45, pz + 1.15);
    cols.push({ cx: px, cz: pz, sx: 3.2, sz: 1.8, h: 2.3 });
    // the scoreboard (hand-hung numbers) and a bench or two for the spectators
    const sx0 = W / 2 - 1.6, sz0 = -D / 2 + 0.8; box(g, 2.2, 1.4, 0.2, 0x1f3a2a, sx0, 0.6, sz0); for (let k = 0; k < 3; k++) box(g, 0.45, 0.5, 0.03, 0xf2efe6, sx0 - 0.6 + k * 0.6, 1.05, sz0 + 0.12); box(g, 0.12, 0.6, 0.12, 0x5a4a3a, sx0 - 0.9, 0, sz0); box(g, 0.12, 0.6, 0.12, 0x5a4a3a, sx0 + 0.9, 0, sz0);
    tree(-W / 2 + 0.9, D / 2 - 0.9, 1.0); tree(W / 2 - 0.9, D / 2 - 0.9, 1.0);
  }
  return { group: g, roof, colliders: cols, height: 0.2 };
}

function buildLift(def) {
  const W = def.w * UNIT, D = def.d * UNIT, g = new THREE.Group(), roof = new THREE.Group(), cols = [];
  box(g, W, 0.35, D, 0x464c55, 0, -0.18, 0);
  const ring = new THREE.Mesh(new THREE.RingGeometry(3.4, 4.2, 28), new THREE.MeshBasicMaterial({ color: 0xf1c40f })); ring.rotation.x = -Math.PI / 2; ring.position.set(0, 0.2, 0.5); g.add(ring);
  box(g, W, 11, 1.2, 0x39414b, 0, 0, -D / 2 + 0.6); cols.push({ cx: 0, cz: -D / 2 + 0.6, sx: W, sz: 1.2 });
  box(g, 5.2, 8, 0.3, 0x5b6572, -2.7, 0, -D / 2 + 1.3); box(g, 5.2, 8, 0.3, 0x5b6572, 2.7, 0, -D / 2 + 1.3);
  for (let i = 0; i < 6; i++) { box(g, 0.5, 8, 0.32, i % 2 ? 0x1a1a1a : 0xf1c40f, -5 + i * 0.9 - 0.2, 0, -D / 2 + 1.5); box(g, 0.5, 8, 0.32, i % 2 ? 0x1a1a1a : 0xf1c40f, 0.5 + i * 0.9, 0, -D / 2 + 1.5); }
  for (const x of [-W / 2 + 0.6, W / 2 - 0.6]) { box(g, 1.0, 7, 1.0, 0x59616d, x, 0, D / 2 - 1); cols.push({ cx: x, cz: D / 2 - 1, sx: 1, sz: 1 }); box(g, 0.5, 0.5, 0.5, 0xffa500, x, 7, D / 2 - 1, { emissive: 0xffa500, emissiveIntensity: 1.4 }); }
  box(g, W - 1, 0.7, 0.7, 0x59616d, 0, 6.4, D / 2 - 1);
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(6, 1.2), new THREE.MeshBasicMaterial({ map: signTexture('THE LIFT - STAFF ONLY', '#3a1010') })); sign.position.set(0, 5.6, D / 2 - 0.62); g.add(sign);
  // the shaft: a dark pit in the deck with a hazard-striped frame; the cage rises out of it and sinks back down
  const pit = new THREE.Mesh(new THREE.PlaneGeometry(5.6, 5.6), new THREE.MeshBasicMaterial({ color: 0x07090c })); pit.rotation.x = -Math.PI / 2; pit.position.set(0, 0.185, 0.5); g.add(pit);
  for (let i = 0; i < 8; i++) { const c = i % 2 ? 0x1a1a1a : 0xf1c40f; box(g, 0.75, 0.06, 0.35, c, -2.6 + i * 0.75, 0.17, -2.3); box(g, 0.75, 0.06, 0.35, c, -2.6 + i * 0.75, 0.17, 3.3); box(g, 0.35, 0.06, 0.75, c, -3.0, 0.17, -2.0 + i * 0.75); box(g, 0.35, 0.06, 0.75, c, 3.0, 0.17, -2.0 + i * 0.75); }
  for (const [x, z] of [[-3.0, -2.3], [3.0, -2.3], [-3.0, 3.3], [3.0, 3.3]]) { box(g, 0.22, 1.1, 0.22, 0xf1c40f, x, 0.17, z); box(g, 0.26, 0.18, 0.26, 0xff8a1a, x, 1.27, z, { emissive: 0xff6a1a, emissiveIntensity: 0.6 }); }
  const cage = new THREE.Group(); cage.userData.keep = true; g.add(cage); const REST = -4.2; cage.position.set(0, REST, 0.5);
  const cm = (w, h, d, c, x, y, z, o) => { const m = new THREE.Mesh(unit, stdMat(c, o)); m.scale.set(w, h, d); m.position.set(x, y + h / 2, z); m.castShadow = true; cage.add(m); return m; };
  cm(5.2, 0.2, 5.2, 0x3a4048, 0, -0.2, 0); for (const [x, z] of [[-2.5, -2.5], [2.5, -2.5], [-2.5, 2.5], [2.5, 2.5]]) cm(0.14, 2.6, 0.14, 0xf1c40f, x, 0, z); cm(5.2, 0.16, 5.2, 0x3a4048, 0, 2.6, 0);
  for (const z of [-2.5]) cm(5.2, 0.08, 0.06, 0xf1c40f, 0, 1.1, z); for (const x of [-2.5, 2.5]) cm(0.06, 0.08, 5.2, 0xf1c40f, x, 1.1, 0);
  const lamp = cm(0.3, 0.2, 0.3, 0xff8a1a, 0, 2.76, 0, { emissive: 0xff6a1a, emissiveIntensity: 0.2 });
  const crates = new THREE.Group(); cage.add(crates);
  // intercom post outside the platform: Sam can order goods here
  const ix = W / 2 + 0.9, iz = D / 2 - 0.4; box(g, 0.14, 1.3, 0.14, 0x59616d, ix, 0, iz); box(g, 0.45, 0.6, 0.25, 0xf1c40f, ix, 1.2, iz); box(g, 0.3, 0.2, 0.03, 0x1a1a1a, ix, 1.45, iz + 0.13); box(g, 0.12, 0.12, 0.04, 0xc0392b, ix, 1.28, iz + 0.13, { emissive: 0xc0392b, emissiveIntensity: 0.8 });
  // state machine: down -> rising -> open -> sinking -> down. Deliveries open for 2 s; a passenger ride stays open until released.
  const anim = { st: 'down', t: 0, onOpen: null, hold: false, onDown: null };
  const call = (onOpen, hold) => { anim.st = 'rising'; anim.t = 0; anim.onOpen = onOpen; anim.hold = !!hold; };
  const deliver = (colors, onLand) => { crates.clear(); colors.slice(0, 9).forEach((c, i) => { const m = new THREE.Mesh(unit, stdMat(c)); m.scale.set(0.9, 0.8, 0.9); m.position.set(-1.1 + (i % 3) * 1.1, 0.4, -1.1 + Math.floor(i / 3) * 1.1); m.castShadow = true; crates.add(m); }); call(() => { if (onLand) onLand(); crates.clear(); }, false); };
  const release = (onDown) => { if (anim.st !== 'open') return false; anim.st = 'sinking'; anim.t = 0; anim.onDown = onDown; return true; };
  const ease = (k) => (1 - Math.cos(Math.min(1, k) * Math.PI)) / 2;
  const update = (dt) => {
    let y = REST; anim.t += dt; const T = anim.t;
    if (anim.st === 'rising') { y = REST + (0.17 - REST) * ease(T / 3); if (T >= 3) { anim.st = 'open'; anim.t = 0; if (anim.onOpen) { const f = anim.onOpen; anim.onOpen = null; f(); } } }
    else if (anim.st === 'open') { y = 0.17; if (!anim.hold && T >= 2) { anim.st = 'sinking'; anim.t = 0; } }
    else if (anim.st === 'sinking') { y = 0.17 + (REST - 0.17) * ease(T / 3); if (T >= 3) { anim.st = 'down'; if (anim.onDown) { const f = anim.onDown; anim.onDown = null; f(); } } }
    lamp.material.emissiveIntensity = anim.st !== 'down' && Math.sin(T * 10) > 0 ? 1.6 : 0.2;
    cage.position.y = y; cage.visible = y > REST + 0.3;
  };
  update(0);
  return { group: g, roof, colliders: cols, height: 11, update, everyFrame: true, deliver, call, release, cageY: () => cage.position.y, state: () => anim.st, hatch: { x: ix, z: iz + 0.9 }, busy: () => anim.st !== 'down' };
}

function buildTunnel(def) {
  const W = def.w * UNIT, D = def.d * UNIT, g = new THREE.Group(), roof = new THREE.Group(), cols = [];
  box(g, W, 0.3, D, 0x55595f, 0, -0.16, 0);
  box(g, W + 4, 6, 6.5, 0x56704a, 0, 0, -D / 2 + 3.25); box(g, W + 1, 3, 5.2, 0x45603f, 0, 6, -D / 2 + 3.0); box(g, W - 3, 2, 4, 0x6f8a58, 0, 9, -D / 2 + 2.8);
  for (const [tx, tz, s] of [[-5, -5, 1], [4, -4.5, 1.2], [0, -5.5, 0.9], [7, -2, 0.8], [-7, -2.5, 1]]) { box(g, 0.3, 1.2, 0.3, 0x5a3b22, tx, 5.5, tz); const cn = new THREE.Mesh(new THREE.ConeGeometry(1.3 * s, 3 * s, 6), stdMat(0x2f6a3a, { flatShading: true })); cn.position.set(tx, 8.5 * 1, tz); cn.position.y = 7.4 + 1.5 * s; g.add(cn); }
  // hill
  box(g, 1.2, 6, 1.4, 0xbfc2c7, -3, 0, -0.9); box(g, 1.2, 6, 1.4, 0xbfc2c7, 3, 0, -0.9); box(g, 7.4, 1.4, 1.4, 0xbfc2c7, 0, 5.6, -0.9);
  box(g, 4.8, 5.6, 0.4, 0x050505, 0, 0, -1.4);                                      // dark mouth
  cols.push({ cx: 0, cz: -D / 2 + 3.25, sx: W + 4, sz: 6.5 }, { cx: 0, cz: -1.6, sx: 7.4, sz: 3 });
  for (let i = 0; i < 6; i++) box(g, 0.5, 0.05, 6, i % 2 ? 0x111111 : 0xf1c40f, -2.75 + i, 0.05, 1.8 - 3.5);
  // boom barrier
  box(g, 0.5, 1.1, 0.5, 0x333, -3.2, 0, 3.2); for (let i = 0; i < 6; i++) box(g, 1.1, 0.16, 0.16, i % 2 ? 0xffffff : 0xcc2222, -2.6 + i * 1.1, 1.0, 3.2);
  cols.push({ cx: 0, cz: 3.2, sx: 7, sz: 0.4 });
  box(g, 2.4, 2.4, 2.4, 0x7a8088, W / 2 - 1.3, 0, 3.6); box(g, 2.7, 0.3, 2.7, 0x333b45, W / 2 - 1.3, 2.4, 3.6); box(g, 1.0, 0.8, 0.05, 0xffdd88, W / 2 - 1.3, 1.1, 2.4, { emissive: 0xffdd88, emissiveIntensity: 0.6 });
  cols.push({ cx: W / 2 - 1.3, cz: 3.6, sx: 2.4, sz: 2.4 });
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(4.6, 1.15), new THREE.MeshBasicMaterial({ map: signTexture('RESTRICTED - NO ENTRY', '#5a0d0d') })); sign.position.set(0, 3.3, 3.45); g.add(sign);
  box(g, 0.2, 3.3, 0.2, 0x333, -2.2, 0, 3.3); box(g, 0.2, 3.3, 0.2, 0x333, 2.2, 0, 3.3);
  return { group: g, roof, colliders: cols, height: 8 };
}

// ---------- construction site ----------
export function buildSite(def) {
  const W = def.w * UNIT, D = def.d * UNIT, H = Math.max(2, (def.floors || 1) * WALL_H), g = new THREE.Group();
  box(g, W + 0.4, 0.2, D + 0.4, 0x8b7355, 0, -0.1, 0);
  const f = FACADES[def.wall] || FACADES.tan;
  const shell = new THREE.Mesh(unit, new THREE.MeshStandardMaterial({ color: new THREE.Color(f.base), transparent: true, opacity: 0.88, roughness: 1 }));
  shell.castShadow = true; g.add(shell);
  const post = (x, z) => box(g, 0.14, H + 1.2, 0.14, 0xe0a21b, x, 0, z);
  post(-W / 2, -D / 2); post(W / 2, -D / 2); post(-W / 2, D / 2); post(W / 2, D / 2);
  const rails = new THREE.Group(); g.add(rails);
  const signP = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 0.6), new THREE.MeshBasicMaterial({ map: signTexture('Under construction', '#7a5a00') })); signP.position.set(0, 1.4, D / 2 + 0.3); g.add(signP);
  const crates = new THREE.Group(); g.add(crates);
  const state = { crates: -1, rails: -1 };
  function update(progress, haveTotal, needTotal) {
    const supply = needTotal ? haveTotal / needTotal : 1;
    const hh = Math.max(0.15, H * progress);
    shell.scale.set(W - 0.5, hh, D - 0.5); shell.position.set(0, hh / 2, 0);
    const nc = Math.min(9, Math.ceil(supply * 9)) * (progress < 1 ? 1 : 0);
    if (nc !== state.crates) {
      state.crates = nc; crates.clear();
      for (let i = 0; i < nc; i++) box(crates, 0.8, 0.8, 0.8, i % 3 ? 0xb5834a : 0xa8442f, -W / 2 - 1.1 + (i % 3) * 0.9, (i / 9 | 0) * 0.8, D / 2 + 0.2 + ((i / 3) | 0) * 0.9);
    }
    const nr = Math.floor(progress * 4); if (nr !== state.rails) {
      state.rails = nr; rails.clear();
      for (let k = 1; k <= nr + 1; k++) { const y = Math.min(H + 0.8, k * H / 3.2); box(rails, W + 0.3, 0.08, 0.08, 0xbdbdbd, 0, y, D / 2 + 0.1); box(rails, 0.08, 0.08, D + 0.3, 0xbdbdbd, W / 2 + 0.1, y, 0); }
    }
  }
  update(0, 0, 1);
  return { group: g, update, height: H };
}

// ---------- interior (built lazily) ----------
/** What a piece of furniture was in the town's era: no tellies before the electricity, no home computers before the computer age. */
const ERA_SWAP = [{ kitchen: 'range', tv: 'radio', tvunit: 'radio', hifi: 'gramophone', fridgefreezer: 'larder', washer: 'mangle', homepc: 'desk', terminal: 'ledger', reception: 'reception0' }, { homepc: 'desk', terminal: 'ledger', reception: 'reception0' }, {}];
function eraT(t, era) { return (ERA_SWAP[Math.min(2, era)] || {})[t] || t; }
const patCache = {};
/** A 90s floor: patterned carpet, chequered lino, bathroom tiles or varnished boards. */
function floorMat(kind, col) {
  const k = kind + col; if (patCache[k]) return patCache[k];
  const c = document.createElement('canvas'); c.width = c.height = 32; const x = c.getContext('2d'), base = '#' + col.toString(16).padStart(6, '0'), cc = new THREE.Color(col);
  const shade = (f) => '#' + cc.clone().multiplyScalar(f).getHexString();
  x.fillStyle = base; x.fillRect(0, 0, 32, 32);
  if (kind === 'lino') { x.fillStyle = shade(0.55); for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) if ((i + j) % 2) x.fillRect(i * 8, j * 8, 8, 8); }
  else if (kind === 'tiles') { x.fillStyle = shade(0.82); for (let i = 0; i <= 4; i++) { x.fillRect(i * 8, 0, 1, 32); x.fillRect(0, i * 8, 32, 1); } }
  else if (kind === 'boards') { x.fillStyle = shade(0.7); for (let i = 0; i < 4; i++) { x.fillRect(0, i * 8, 32, 1); x.fillRect(((i * 13) % 32), i * 8, 1, 8); } }
  else { for (let i = 0; i < 60; i++) { x.fillStyle = i % 3 ? shade(0.82) : shade(1.18); const r = 1 + (i % 3); x.fillRect((i * 37) % 32, (i * 53) % 32, r, r); } x.fillStyle = shade(0.7); for (let i = 0; i < 8; i++) { x.beginPath(); x.arc((i * 11) % 32, (i * 7) % 32, 3, 0, Math.PI * 1.3); x.stroke(); } }   // a swirly carpet
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.magFilter = THREE.NearestFilter; t.colorSpace = THREE.SRGBColorSpace;
  return (patCache[k] = new THREE.MeshStandardMaterial({ map: t, roughness: kind === 'tiles' || kind === 'lino' ? 0.5 : 0.95 }));
}
/** The rooms of a planned interior: inside walls with doorways (a frame and an open door in each), floors and ceiling lights. */
function buildRooms(b, g) {
  const lay = b.layout, H = WALL_H, lv = (k) => { if (!k) return g; let lg = g.userData.lv[k]; if (!lg) { lg = g.userData.lv[k] = new THREE.Group(); lg.userData.keep = true; g.add(lg); } return lg; };
  for (const w of lay.walls || []) {
    const P = wallPieces(w), k = w.k || 0, y0 = k ? k * H + 0.02 : 0.14, top = (k + 1) * H - 0.27, hgt = top - y0, grp = lv(k), m = stdMat(w.col || 0xe8dcc0, { roughness: 1 });
    for (const [x0, x1, z0, z1] of P.pieces) { const s = new THREE.Mesh(unit, m); s.scale.set(x1 - x0, hgt, z1 - z0); s.position.set((x0 + x1) / 2, y0 + hgt / 2, (z0 + z1) / 2); s.receiveShadow = true; grp.add(s); }
    for (const [a, c] of P.doors) {
      const mid = (a + c) / 2, len = c - a, lin = top - (y0 + 2.1), at = (s, h, y, ww, dd, col) => { const o = new THREE.Mesh(unit, stdMat(col)); o.scale.set(P.alongX ? ww : dd, h, P.alongX ? dd : ww); o.position.set(P.alongX ? s : P.c, y, P.alongX ? P.c : s); grp.add(o); return o; };
      if (lin > 0.05) at(mid, lin, y0 + 2.1 + lin / 2, len, 0.12, w.col || 0xe8dcc0);   // the wall over the door
      at(a + 0.04, 2.1, y0 + 1.05, 0.08, 0.16, 0xf4f0e6); at(c - 0.04, 2.1, y0 + 1.05, 0.08, 0.16, 0xf4f0e6); at(mid, 0.08, y0 + 2.1, len, 0.16, 0xf4f0e6);   // door frame
      const leaf = new THREE.Mesh(unit, stdMat(0xe8e0cc)); leaf.scale.set(P.alongX ? 0.05 : 0.95, 2.0, P.alongX ? 0.95 : 0.05); leaf.position.set(P.alongX ? a + 0.08 : P.c + 0.5, y0 + 1.0, P.alongX ? P.c + 0.5 : a + 0.08); grp.add(leaf);   // an open door
    }
  }
  for (const f of lay.floors || []) { const k = f.k || 0, o = new THREE.Mesh(new THREE.PlaneGeometry(f.x1 - f.x0, f.z1 - f.z0), floorMat(f.kind, f.col)); o.rotation.x = -Math.PI / 2; o.position.set((f.x0 + f.x1) / 2, (k ? k * H + 0.03 : 0.15), (f.z0 + f.z1) / 2); o.receiveShadow = true; o.material.map.repeat.set((f.x1 - f.x0) / 1.5, (f.z1 - f.z0) / 1.5); lv(k).add(o); }
  for (const p of lay.lights || []) { const k = p.k || 0, y = (k + 1) * H - 0.3, grp = lv(k); const cord = new THREE.Mesh(unit, stdMat(0xf4f0e6)); cord.scale.set(0.02, 0.35, 0.02); cord.position.set(p.x, y - 0.15, p.z); grp.add(cord); const sh = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.24, 0.22, 8), stdMat(0xf4e0b0, { emissive: 0xffd080, emissiveIntensity: 0.55 })); sh.position.set(p.x, y - 0.4, p.z); grp.add(sh); }
}
/** The colliders of a planned interior's walls (the solid stretches between doorways), on their own storeys. */
export function roomColliders(lay) {
  const out = [];
  for (const w of (lay && lay.walls) || []) for (const [x0, x1, z0, z1] of wallPieces(w).pieces) { const k = w.k || 0, c = { cx: (x0 + x1) / 2, cz: (z0 + z1) / 2, sx: x1 - x0, sz: z1 - z0 }; if (k) { c.lo = k * WALL_H - 0.3; c.h = k * WALL_H + 2.3; } else c.h = 2.6; out.push(c); }
  return out;
}
export function buildInterior(b) {
  const g = new THREE.Group(), lay = b.layout;
  if (!lay) return g;
  for (const f of lay.furniture) {
    const era = b.era ?? 2, t = eraT(f.t, era);
    const m = makeFurniture(t); m.position.set(f.x, 0.06, f.z); m.rotation.y = (f.r || 0) * Math.PI / 2; g.add(m);
  }
  colorize(g); mergeByMaterial(g);   // a whole room of furniture in a few draw calls
  // the storeys upstairs, one group each (hidden above the floor Sam is on)
  g.userData.lv = [];
  for (const f of upperFurniture(b.def)) {
    let lg = g.userData.lv[f.k]; if (!lg) { lg = g.userData.lv[f.k] = new THREE.Group(); lg.userData.keep = true; g.add(lg); }
    const era = b.era ?? 2, t = eraT(f.t, era);
    const m = makeFurniture(t); m.position.set(f.x, f.k * WALL_H + 0.03, f.z); m.rotation.y = (f.r || 0) * Math.PI / 2; lg.add(m);
  }
  if (lay.walls || lay.floors || lay.lights) { buildRooms(b, g); colorize(g); mergeByMaterial(g); }   // (the ground-floor rooms merge in too)
  for (const lg of g.userData.lv) if (lg) { colorize(lg); mergeByMaterial(lg); }
  return g;
}
/** Colliders for the furniture upstairs: they only block at their own storey (lo..h). */
export function upperColliders(def) { return upperFurniture(def).filter((f) => f.solid).map((f) => ({ cx: f.x, cz: f.z, sx: f.sx * 0.92, sz: f.sz * 0.92, lo: f.k * WALL_H - 0.3, h: f.k * WALL_H + 2.3 })); }

const TOPS = { bed: 0.55, dbed: 0.55, bunk: 0, cot: 0, table: 0.78, sofa: 0.8, armchair: 0.8, coffeetable: 0.45, desk: 0.78, kitchen: 0.95, bath: 0.6, dresser: 0.85, bedside: 0.6, tvunit: 0.6, phonetable: 0.75, homepc: 0.78, chest: 0.6, crate: 0.7, bench: 0.5, pooltable: 0.85, snookertable: 0.85 };
export function furnitureColliders(lay) {
  const out = [];
  for (const f of lay.furniture) {
    const d = FURN[f.t]; if (!d || !d.solid) continue;
    let [sx, sz] = d.s; if ((f.r || 0) % 2) [sx, sz] = [sz, sx];
    const top = d.h || TOPS[f.t];   // low pieces can be jumped onto and stood on
    out.push({ cx: f.x, cz: f.z, sx: sx * 0.92, sz: sz * 0.92, h: top || 2.5, top });
  }
  return out;
}

// ---------- primitive-era pieces ----------
function buildCamp(def, g, roof, cols) {
  g.clear(); const W = def.w * UNIT, D = def.d * UNIT;
  const dirt = new THREE.Mesh(new THREE.CylinderGeometry(3.4, 3.6, 0.12, 14), stdMat(0x8a7656)); dirt.position.y = 0.05; dirt.receiveShadow = true; g.add(dirt);
  for (let i = 0; i < 9; i++) { const a = i / 9 * Math.PI * 2; const st = box(g, 0.45, 0.32, 0.4, i % 2 ? 0x8d8a82 : 0x77746c, Math.cos(a) * 1.0, 0.05, Math.sin(a) * 1.0); st.rotation.y = a; }
  for (let i = 0; i < 4; i++) { const a = i / 4 * Math.PI * 2 + 0.4; const lg = box(g, 1.2, 0.18, 0.18, 0x4a3320, Math.cos(a) * 0.35, 0.12, Math.sin(a) * 0.35); lg.rotation.y = a; }
  const fl = new THREE.Group(); fl.userData.keep = true; g.add(fl); const fm = new THREE.MeshBasicMaterial({ color: 0xff8a1a }), fm2 = new THREE.MeshBasicMaterial({ color: 0xffd24a });
  const f1 = new THREE.Mesh(new THREE.ConeGeometry(0.55, 1.2, 5), fm); f1.position.y = 0.75; fl.add(f1); const f2 = new THREE.Mesh(new THREE.ConeGeometry(0.3, 0.8, 5), fm2); f2.position.y = 0.6; fl.add(f2); const f3 = new THREE.Mesh(new THREE.ConeGeometry(0.28, 0.9, 5), fm); f3.position.set(0.3, 0.6, 0.2); fl.add(f3);
  // tripod + pot
  for (const [x, z] of [[-1.5, 0.2], [1.2, 0.9], [0.3, -1.4]]) { const pl = box(g, 0.07, 2.0, 0.07, 0x3a2a1a, x * 0.55, 0.0, z * 0.55); pl.rotation.z = (x > 0 ? -1 : 1) * 0.28; }
  const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.22, 0.3, 8), stdMat(0x222222)); pot.position.y = 1.05; pot.castShadow = true; g.add(pot);
  for (let i = 0; i < 4; i++) { const a = i / 4 * Math.PI * 2 + Math.PI / 4; const lg = box(g, 1.7, 0.4, 0.5, 0x6a4a2a, Math.cos(a) * 2.5, 0.0, Math.sin(a) * 2.5); lg.rotation.y = -a + Math.PI / 2; box(g, 0.2, 0.2, 0.52, 0x5a3a1c, Math.cos(a) * 2.5 + 0.6 * Math.sin(a), 0.4, Math.sin(a) * 2.5 - 0.6 * Math.cos(a)).rotation.y = -a + Math.PI / 2; }
  cols.push({ cx: 0, cz: 0, sx: 2.4, sz: 2.4 });
  const update = (dt, t) => { const k = 1 + Math.sin(t * 17) * 0.12 + Math.sin(t * 29) * 0.08; f1.scale.set(1 + Math.sin(t * 13) * 0.08, k, 1); f2.scale.set(1, 1 + Math.sin(t * 23 + 1) * 0.2, 1); f3.scale.set(1, 1 + Math.sin(t * 19 + 2) * 0.25, 1); };
  return { group: g, roof, colliders: cols, height: 1.2, update, fire: { x: 0, y: 1.0, z: 0 }, smokeSrc: { x: 0, y: 1.6, z: 0 } };
}
/** A red English pillar box on a little paved square, with a flag that pops up when there is post. */
function buildPostbox(def, g, roof, cols) {
  g.clear(); const pave = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.1, 3.2), stdMat(0xa29a8a)); pave.position.y = 0.05; pave.receiveShadow = true; g.add(pave);
  const red = stdMat(0xc0241e, { roughness: 0.55 }), black = stdMat(0x1a1a1a);
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.46, 1.35, 12), red); body.position.y = 0.8; body.castShadow = true; g.add(body);
  const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.12, 12), red); cap.position.y = 1.52; g.add(cap);
  const dome = new THREE.Mesh(new THREE.SphereGeometry(0.46, 12, 6, 0, Math.PI * 2, 0, Math.PI / 2), red); dome.position.y = 1.58; dome.castShadow = true; g.add(dome);
  const base = new THREE.Mesh(new THREE.CylinderGeometry(0.52, 0.55, 0.14, 12), black); base.position.y = 0.17; g.add(base);
  box(g, 0.42, 0.06, 0.06, 0x111111, 0, 1.22, 0.42); box(g, 0.3, 0.16, 0.02, 0xf0e6c8, 0, 0.9, 0.45);
  const flag = new THREE.Group(); flag.position.set(0.5, 1.0, 0); const pole = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.6, 0.05), stdMat(0x333333)); pole.position.y = 0.3; const f = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.2, 0.3), stdMat(0xffd23f)); f.position.set(0, 0.55, 0.15); flag.add(pole, f); g.add(flag);
  flag.userData.keep = true; g.userData.flag = flag;
  cols.push({ cx: 0, cz: 0, sx: 1.0, sz: 1.0 }); return { group: g, roof, colliders: cols, height: 1.8, flag };
}
/** The red K6 telephone box. */
function buildPhonebox(def, g, roof, cols) {
  g.clear(); const pave = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.1, 3.2), stdMat(0xa29a8a)); pave.position.y = 0.05; pave.receiveShadow = true; g.add(pave);
  const red = 0xc0241e, glass = { color: 0x9fd0e8 };
  box(g, 1.1, 0.15, 1.1, red, 0, 0.1, 0);
  for (const [x, z] of [[-0.5, -0.5], [0.5, -0.5], [-0.5, 0.5], [0.5, 0.5]]) box(g, 0.14, 2.3, 0.14, red, x, 0.25, z);
  for (const [x, z, sx, sz] of [[0, 0.5, 0.86, 0.04], [0, -0.5, 0.86, 0.04], [0.5, 0, 0.04, 0.86], [-0.5, 0, 0.04, 0.86]]) {
    box(g, sx, 1.8, sz, 0x9fd0e8, x, 0.45, z, { transparent: true, opacity: 0.55, roughness: 0.2 });
    for (let k = 0; k < 5; k++) box(g, sx || 0.05, 0.05, sz || 0.05, red, x, 0.45 + k * 0.42, z);
  }
  box(g, 1.15, 0.32, 1.15, red, 0, 2.55, 0); box(g, 1.0, 0.18, 1.0, red, 0, 2.87, 0);
  const top = new THREE.Mesh(new THREE.SphereGeometry(0.62, 10, 4, 0, Math.PI * 2, 0, Math.PI / 2), stdMat(red)); top.scale.y = 0.4; top.position.y = 3.02; g.add(top);
  for (const [x, z, r] of [[0, 0.585, 0], [0, -0.585, Math.PI], [0.585, 0, Math.PI / 2], [-0.585, 0, -Math.PI / 2]]) { const t = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.2), new THREE.MeshBasicMaterial({ map: signTexture('TELEPHONE', '#1a1a1a') })); t.position.set(x, 2.71, z); t.rotation.y = r; g.add(t); }
  box(g, 0.3, 0.4, 0.2, 0x1a1a1a, 0, 1.2, -0.38);
  cols.push({ cx: 0, cz: 0, sx: 1.15, sz: 1.15 }); return { group: g, roof, colliders: cols, height: 3.2 };
}
function buildBusStop(def, g, roof, cols) {
  g.clear(); const pave = new THREE.Mesh(new THREE.BoxGeometry(3.6, 0.1, 3.4), stdMat(0xa29a8a)); pave.position.y = 0.05; pave.receiveShadow = true; g.add(pave);
  box(g, 3.0, 2.2, 0.06, 0x9fd0e8, 0, 0.1, -1.3, { transparent: true, opacity: 0.45, roughness: 0.2 });
  for (const x of [-1.5, 1.5]) { box(g, 0.1, 2.4, 0.1, 0x2a5a3a, x, 0.1, -1.3); box(g, 0.06, 2.2, 1.2, 0x9fd0e8, x, 0.1, -0.7, { transparent: true, opacity: 0.45 }); }
  box(g, 3.3, 0.12, 1.6, 0x2a5a3a, 0, 2.5, -0.75); box(g, 2.4, 0.08, 0.45, 0x8a5a33, 0, 0.5, -0.9); box(g, 0.08, 0.5, 0.3, 0x333, -1.0, 0, -0.9); box(g, 0.08, 0.5, 0.3, 0x333, 1.0, 0, -0.9);
  box(g, 0.8, 0.4, 0.02, 0x1a1a1a, 0.6, 1.4, -1.25); box(g, 0.5, 0.3, 0.02, 0xf1c40f, -0.6, 1.0, -1.25);          // graffiti + timetable
  box(g, 0.08, 2.7, 0.08, 0x666, 1.6, 0.1, 1.2); const s = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.05, 14), stdMat(0xc0241e)); s.rotation.x = Math.PI / 2; s.position.set(1.6, 2.65, 1.2); g.add(s);
  const bus = new THREE.Mesh(new THREE.PlaneGeometry(0.42, 0.14), new THREE.MeshBasicMaterial({ map: signTexture('BUS', '#1a3a8a') })); bus.position.set(1.6, 2.65, 1.23); g.add(bus);
  cols.push({ cx: 0, cz: -1.3, sx: 3.0, sz: 0.2 }, { cx: -1.5, cz: -0.7, sx: 0.2, sz: 1.2 }, { cx: 1.5, cz: -0.7, sx: 0.2, sz: 1.2 }); return { group: g, roof, colliders: cols, height: 2.7 };
}
function buildBandstand(def, g, roof, cols, tree) {
  box(g, 1.0, 0.04, 3.0, 0xcdb58a, 0, 0.1, 2.6);
  const base = new THREE.Mesh(new THREE.CylinderGeometry(2.6, 2.7, 0.7, 8), stdMat(0xd8d0c0)); base.position.y = 0.35; base.castShadow = true; base.receiveShadow = true; g.add(base);
  const deck = new THREE.Mesh(new THREE.CylinderGeometry(2.55, 2.55, 0.06, 8), stdMat(0x8a5a33)); deck.position.y = 0.72; g.add(deck);
  for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2 + Math.PI / 8; box(g, 0.14, 2.6, 0.14, 0xf4f4f0, Math.cos(a) * 2.35, 0.72, Math.sin(a) * 2.35); if (i !== 2) { const r = box(g, 1.75, 0.08, 0.06, 0xf4f4f0, Math.cos(a + Math.PI / 8) * 2.18, 1.4, Math.sin(a + Math.PI / 8) * 2.18); r.rotation.y = -(a + Math.PI / 8) + Math.PI / 2; } }
  const rf = new THREE.Mesh(new THREE.ConeGeometry(3.0, 1.6, 8), stdMat(0x2a6a4a, { flatShading: true })); rf.position.y = 3.3 + 0.8; rf.rotation.y = Math.PI / 8; rf.castShadow = true; g.add(rf);
  const trim = new THREE.Mesh(new THREE.CylinderGeometry(3.0, 3.0, 0.25, 8), stdMat(0xf4f4f0)); trim.position.y = 3.32; trim.rotation.y = Math.PI / 8; g.add(trim);
  box(g, 0.1, 0.6, 0.1, 0xd8c070, 0, 4.8, 0);
  for (const x of [-0.8, 0.6]) { box(g, 0.5, 0.05, 0.5, 0x333, x, 1.6, -0.4); box(g, 0.04, 0.9, 0.04, 0x333, x, 0.75, -0.4); }    // music stands
  for (const [x, z] of [[-2.9, 2.6], [2.9, 2.6]]) { box(g, 2.0, 0.08, 0.5, 0x8a5a33, x, 0.45, z); box(g, 2.0, 0.45, 0.08, 0x8a5a33, x, 0.5, z - 0.22); }
  tree(-3.2, -3.2, 0.8); tree(3.2, -3.2, 0.8);
  cols.push({ cx: 0, cz: 0, sx: 4.6, sz: 4.6 }); return { group: g, roof, colliders: cols, height: 4.2 };
}
function buildAllotment(def, g, roof, cols, rnd) {
  g.clear(); const W = def.w * UNIT, D = def.d * UNIT;
  const grass = new THREE.Mesh(new THREE.BoxGeometry(W - 0.3, 0.1, D - 0.3), stdMat(0x5e8a3e)); grass.position.y = 0.03; grass.receiveShadow = true; g.add(grass);
  const greens = [0x4a8a2a, 0x6aa63a, 0x3a7a3a, 0x8aa64a];
  for (let i = 0; i < 4; i++) {
    const x = -W / 2 + 1.3 + (i % 2) * 2.7, z = -D / 2 + 1.4 + Math.floor(i / 2) * 3.0; box(g, 2.3, 0.18, 2.4, 0x5a4026, x, 0, z);
    for (let k = 0; k < 4; k++) for (let j = 0; j < 4; j++) { const h = 0.25 + rnd() * 0.35; box(g, 0.32, h, 0.32, greens[(i + k) % 4], x - 0.85 + j * 0.56, 0.18, z - 0.85 + k * 0.56); }
    if (i === 1) for (const cx of [-0.6, 0, 0.6]) box(g, 0.04, 1.6, 0.04, 0x9a7a4a, x + cx, 0.18, z - 1.0);
  }
  box(g, 1.6, 1.9, 1.3, 0x5a6a4a, W / 2 - 1.1, 0, D / 2 - 0.9); const rf = new THREE.Mesh(prism(1.9, 0.6, 1.6), stdMat(0x3a3a3a)); rf.position.set(W / 2 - 1.1, 1.9, D / 2 - 0.9); rf.rotation.y = Math.PI / 2; g.add(rf);
  const butt = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 0.9, 10), stdMat(0x2a4a2a)); butt.position.set(W / 2 - 2.3, 0.45, D / 2 - 0.6); g.add(butt);
  box(g, 0.6, 0.06, 0.3, 0x6a4a2a, -W / 2 + 0.8, 0.5, D / 2 - 0.6); box(g, 0.06, 0.5, 0.25, 0x333, -W / 2 + 0.55, 0, D / 2 - 0.6); box(g, 0.06, 0.5, 0.25, 0x333, -W / 2 + 1.05, 0, D / 2 - 0.6);
  cols.push({ cx: W / 2 - 1.1, cz: D / 2 - 0.9, sx: 1.6, sz: 1.3 }); return { group: g, roof, colliders: cols, height: 2.5 };
}
function buildWell(def, g, roof, cols) {
  g.clear(); const dirt = new THREE.Mesh(new THREE.CylinderGeometry(1.8, 1.9, 0.1, 10), stdMat(0x8a8272)); dirt.position.y = 0.04; g.add(dirt);
  const ring = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 1.02, 1.0, 10), stdMat(0x8d8a82, { flatShading: true })); ring.position.y = 0.5; ring.castShadow = true; g.add(ring);
  const water = new THREE.Mesh(new THREE.CylinderGeometry(0.75, 0.75, 0.05, 10), stdMat(0x1f4f7a)); water.position.y = 0.95; g.add(water);
  box(g, 0.14, 2.3, 0.14, 0x5a3b22, -0.95, 0.0, 0); box(g, 0.14, 2.3, 0.14, 0x5a3b22, 0.95, 0.0, 0); box(g, 2.3, 0.14, 0.14, 0x5a3b22, 0, 2.25, 0);
  const rf = new THREE.Mesh(prism(2.7, 0.8, 1.7), roofMaterial(0x7a5a38, 'thatch')); rf.position.y = 2.3; rf.rotation.y = Math.PI / 2; rf.castShadow = true; g.add(rf);
  box(g, 0.05, 0.9, 0.05, 0x3a2a1a, 0, 1.3, 0); box(g, 0.28, 0.28, 0.28, 0x6a4a2a, 0, 0.95, 0);
  cols.push({ cx: 0, cz: 0, sx: 2.0, sz: 2.0 }); return { group: g, roof, colliders: cols, height: 2.5 };
}
function buildStockyard(def) {
  const W = def.w * UNIT, D = def.d * UNIT, g = new THREE.Group(), roof = new THREE.Group(), cols = [], off = doorOffset(def.w);
  box(g, W, 0.14, D, 0x8a7550, 0, -0.04, 0);
  const post = (x, z) => box(g, 0.2, 1.6, 0.2, 0x5a3b22, x, 0, z);
  for (let x = -W / 2 + 0.2; x <= W / 2 - 0.1; x += 2) { post(x, -D / 2 + 0.15); if (Math.abs(x - off) > 1.6) post(x, D / 2 - 0.15); }
  for (let z = -D / 2 + 0.2; z <= D / 2 - 0.1; z += 2) { post(-W / 2 + 0.15, z); post(W / 2 - 0.15, z); }
  for (const y of [0.6, 1.2]) { box(g, W, 0.1, 0.1, 0x7a5a38, 0, y, -D / 2 + 0.15); box(g, W / 2 + off - 1.2, 0.1, 0.1, 0x7a5a38, -W / 4 + off / 2 - 0.6 - 0.0, y, D / 2 - 0.15).position.x = (-W / 2 + (off - 1.2)) / 2; box(g, W / 2 - off - 1.2, 0.1, 0.1, 0x7a5a38, 0, y, D / 2 - 0.15).position.x = ((off + 1.2) + W / 2) / 2; box(g, 0.1, 0.1, D, 0x7a5a38, -W / 2 + 0.15, y, 0); box(g, 0.1, 0.1, D, 0x7a5a38, W / 2 - 0.15, y, 0); }
  cols.push({ cx: 0, cz: -D / 2 + 0.15, sx: W, sz: 0.3, h: 1.3 }, { cx: -W / 2 + 0.15, cz: 0, sx: 0.3, sz: D, h: 1.3 }, { cx: W / 2 - 0.15, cz: 0, sx: 0.3, sz: D, h: 1.3 }, { cx: (-W / 2 + (off - 1.2)) / 2, cz: D / 2 - 0.15, sx: off - 1.2 + W / 2, sz: 0.3, h: 1.3 }, { cx: ((off + 1.2) + W / 2) / 2, cz: D / 2 - 0.15, sx: W / 2 - off - 1.2, sz: 0.3, h: 1.3 });
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 0.6), new THREE.MeshBasicMaterial({ map: signTexture('Stockyard', '#3a2a14') })); sign.position.set(off, 1.9, D / 2 - 0.1); box(g, 0.12, 2.0, 0.12, 0x5a3b22, off - 1.3, 0, D / 2 - 0.1); box(g, 0.12, 2.0, 0.12, 0x5a3b22, off + 1.3, 0, D / 2 - 0.1); g.add(sign);
  // dynamic piles
  const piles = new THREE.Group(); piles.userData.keep = true; g.add(piles); const groups = {}; const mk = (mat, fn, n, x0, z0) => { const gr = new THREE.Group(); gr.position.set(x0, 0.05, z0); piles.add(gr); groups[mat] = []; for (let i = 0; i < n; i++) { const m = fn(i); m.visible = false; gr.add(m); groups[mat].push(m); } };
  const bx = (w, h, d, c) => new THREE.Mesh(new THREE.BoxGeometry(w, h, d), stdMat(c));
  mk('timber', (i) => { const m = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 2.6, 7), stdMat(i % 2 ? 0x8a5a33 : 0x7a4a28)); m.rotation.z = Math.PI / 2; const row = i < 5 ? 0 : i < 9 ? 1 : 2, k = row === 0 ? i : row === 1 ? i - 5 + 0.5 : i - 9 + 1; m.position.set(0, 0.2 + row * 0.35, (k - 2) * 0.42); return m; }, 12, -W / 2 + 2.2, -D / 2 + 1.6);
  mk('stone', (i) => { const m = bx(0.8 + (i % 3) * 0.2, 0.5, 0.7, i % 2 ? 0x9a9a92 : 0x84847c); m.position.set(((i % 4) - 1.5) * 0.85, 0.25 + (i > 7 ? 0.5 : 0), ((i / 4) | 0) % 2 * 0.8 - 0.3); m.rotation.y = i * 0.7; return m; }, 12, -W / 6 - 0.2, -D / 2 + 1.5);
  mk('brick', (i) => { const m = bx(0.45, 0.22, 0.22, 0xa8442f); const r = (i / 4) | 0; m.position.set(((i % 4) - 1.5) * 0.5, 0.11 + r * 0.23, 0); return m; }, 12, W / 6 + 0.6, -D / 2 + 1.4);
  mk('steel', (i) => { const m = bx(0.14, 0.14, 2.2, 0x8b97a3); m.position.set(((i % 4) - 1.5) * 0.18, 0.1 + ((i / 4) | 0) * 0.15, 0); return m; }, 12, W / 2 - 1.5, -D / 2 + 1.5);
  mk('glass', (i) => { const m = bx(0.8, 0.7, 0.5, 0x8fd0e8); m.material = stdMat(0x8fd0e8, { transparent: true, opacity: 0.8 }); m.position.set(((i % 3) - 1) * 0.9, 0.35 + ((i / 3) | 0) * 0.72, 0); return m; }, 9, -W / 2 + 1.6, 1.0);
  mk('food', (i) => { const m = bx(0.55, 0.3, 0.4, i % 2 ? 0xd9c28a : 0xc9b27a); m.position.set(((i % 4) - 1.5) * 0.6, 0.15 + ((i / 8) | 0) * 0.3, ((i / 4) | 0) % 2 * 0.5); return m; }, 12, W / 2 - 2.2, 1.0);
  const per = { timber: 2, stone: 2, brick: 6, steel: 2, glass: 2, food: 3 };
  const update = (dt, t, stock) => { for (const [mat, list] of Object.entries(groups)) { const n = Math.min(list.length, Math.ceil((stock[mat] || 0) / per[mat])); for (let i = 0; i < list.length; i++) list[i].visible = i < n; } };
  return { group: g, roof, colliders: cols, height: 2, update };
}
function buildFarm(def, uid) {
  const W = def.w * UNIT, D = def.d * UNIT, g = new THREE.Group(), roof = new THREE.Group(), cols = [], rnd = mulberry32(uid * 17 + 3);
  box(g, W, 0.12, D, 0x6b5a3a, 0, -0.04, 0);
  // barn (back-left)
  const bw = W * 0.5, bd = D * 0.5, bx = -W / 2 + bw / 2 + 0.2, bz = -D / 2 + bd / 2 + 0.2, mat = facadeMaterial('timber');
  for (const [cx, cz, sx, sz] of [[bx, bz - bd / 2, bw, 0.3], [bx - bw / 2, bz, 0.3, bd], [bx + bw / 2, bz, 0.3, bd], [bx - bw * 0.3, bz + bd / 2, bw * 0.4, 0.3], [bx + bw * 0.3, bz + bd / 2, bw * 0.4, 0.3]]) { const m = new THREE.Mesh(wallGeo(sx, 3.6, sz), mat); m.position.set(cx, 1.8, cz); m.castShadow = true; g.add(m); cols.push({ cx, cz, sx, sz }); }
  const rf = new THREE.Mesh(prism(bw + 1, 2.2, bd + 0.8), roofMaterial(0x8a3a2a, 'tiles')); rf.position.set(bx, 3.6, bz); rf.rotation.y = Math.PI / 2; rf.castShadow = true; roof.add(rf);
  // fields
  const fields = []; const fx0 = -W / 2 + bw + 1.2, plots = [];
  for (let r = 0; r < 2; r++) for (let c = 0; c < 2; c++) plots.push([fx0 + 1.5 + c * 3.1, -D / 2 + 1.7 + r * 3.1]);
  for (let c = 0; c < 4; c++) plots.push([-W / 2 + 1.7 + c * 3.1, D / 2 - 1.9]);
  for (const [px, pz] of plots) { box(g, 2.7, 0.14, 2.7, 0x5a4026, px, 0, pz); const crops = new THREE.Group(); crops.userData.keep = true; crops.position.set(px, 0.1, pz); g.add(crops); const rows = []; for (let k = 0; k < 4; k++) { const m = new THREE.Mesh(new THREE.BoxGeometry(2.3, 1, 0.2), new THREE.MeshStandardMaterial({ color: 0x6aa63a, roughness: 1 })); m.position.set(0, 0, -1 + k * 0.66); crops.add(m); rows.push(m); } fields.push({ x: px, z: pz, rows }); }
  for (let x = -W / 2; x <= W / 2; x += 2) box(g, 0.14, 0.9, 0.14, 0x6a4a2a, x, 0, D / 2 - 0.1); box(g, W, 0.08, 0.08, 0x7a5a38, 0, 0.7, D / 2 - 0.1);
  const update = (dt, t, stock, b) => { for (let i = 0; i < fields.length; i++) { const f = fields[i], node = b && b.fieldNodes && b.fieldNodes[i], gr = node ? node.amount / node.max : 0.6; for (const r of f.rows) { r.scale.y = 0.15 + gr * 0.85; r.position.y = (0.15 + gr * 0.85) / 2; r.material.color.setHex(gr > 0.7 ? 0xc9b44a : 0x6aa63a); } } };
  return { group: g, roof, colliders: cols, height: 4, update, fieldPlots: plots };
}
