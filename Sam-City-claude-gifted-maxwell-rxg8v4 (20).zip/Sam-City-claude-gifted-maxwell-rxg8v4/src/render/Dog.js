import * as THREE from 'three';

const mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.95 });
function boxGeo(parts) {
  const pos = [], nor = [], col = [], idx = []; let n = 0;
  for (const [w, h, d, x, y, z, hex] of parts) {
    const g = new THREE.BoxGeometry(w, h, d); g.translate(x, y, z); const c = new THREE.Color(hex), p = g.attributes.position, nr = g.attributes.normal;
    for (let i = 0; i < p.count; i++) { pos.push(p.getX(i), p.getY(i), p.getZ(i)); nor.push(nr.getX(i), nr.getY(i), nr.getZ(i)); col.push(c.r, c.g, c.b); }
    for (const i of g.index.array) idx.push(i + n); n += p.count;
  }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3)); g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3)); g.setIndex(idx); return g;
}
const COATS = [[0xb8814a, 0x8a5a30], [0x2b2b2e, 0x1a1a1c], [0xe8e0cf, 0xc9bfa8], [0x8a6a4a, 0xf2ece0]];

/** A little low-poly dog that trots after its owner. */
export class Dog {
  constructor(game, owner) {
    this.game = game; this.owner = owner; const [c1, c2] = COATS[Math.floor(Math.random() * COATS.length)];
    this.root = new THREE.Group(); this.body = new THREE.Group(); this.root.add(this.body);
    const m = (parts, x = 0, y = 0, z = 0) => { const k = new THREE.Mesh(boxGeo(parts), mat); k.position.set(x, y, z); return k; };
    this.torso = m([[0.26, 0.26, 0.55, 0, 0, 0, c1], [0.2, 0.08, 0.3, 0, 0.16, -0.05, c2]], 0, 0.38, 0); this.body.add(this.torso);
    this.head = new THREE.Group(); this.head.position.set(0, 0.55, 0.3); this.body.add(this.head);
    this.head.add(m([[0.2, 0.2, 0.2, 0, 0, 0.05, c1], [0.12, 0.1, 0.14, 0, -0.04, 0.2, c2], [0.04, 0.04, 0.02, 0, -0.02, 0.28, 0x111111], [0.06, 0.12, 0.05, -0.1, 0.06, 0, c2], [0.06, 0.12, 0.05, 0.1, 0.06, 0, c2]]));
    this.tail = new THREE.Group(); this.tail.position.set(0, 0.5, -0.28); this.body.add(this.tail); this.tail.add(m([[0.05, 0.05, 0.28, 0, 0.0, -0.12, c2]]));
    this.legs = [[-0.09, 0.2], [0.09, 0.2], [-0.09, -0.2], [0.09, -0.2]].map(([x, z]) => { const g = new THREE.Group(); g.position.set(x, 0.3, z); g.add(m([[0.07, 0.3, 0.07, 0, -0.15, 0, c1]])); this.body.add(g); return g; });
    this.x = owner.x - 1; this.z = owner.z; this.h = owner.heading; this.ph = Math.random() * 6; this.sit = 0; this.still = 0; this.t = Math.random() * 9;
    game.scene.add(this.root);
  }
  update(dt) {
    const o = this.owner, g = this.game; this.t += dt;
    // follow the owner's footsteps (like on a lead) so the dog goes through doors instead of walls
    const tr = this.trail || (this.trail = []), last = tr[tr.length - 1];
    if (!last || Math.hypot(o.x - last.x, o.z - last.z) > 0.3) { tr.push({ x: o.x, z: o.z }); if (tr.length > 120) tr.shift(); }
    const far = Math.hypot(o.x - this.x, o.z - this.z) > 18;
    if (far || o.hidden) { this.x = o.x - Math.sin(o.heading) * 1.2; this.z = o.z - Math.cos(o.heading) * 1.2; tr.length = 0; }
    while (tr.length > 1 && Math.hypot(tr[0].x - this.x, tr[0].z - this.z) < 0.35) tr.shift();
    let ahead = 0, px = this.x, pz = this.z; for (const q of tr) { ahead += Math.hypot(q.x - px, q.z - pz); px = q.x; pz = q.z; } ahead += Math.hypot(o.x - px, o.z - pz);
    if (this.still > 1.2 && !this.off) this.off = this.kerbside();   // never sit about in the middle of the road
    if (this.off && (ahead > 3 || Math.hypot(this.off.x - this.x, this.off.z - this.z) < 0.1)) this.off = null;
    const tgt = this.off || (tr.length ? tr[0] : { x: o.x, z: o.z }), dx = tgt.x - this.x, dz = tgt.z - this.z, d = Math.hypot(dx, dz);
    let speed = 0;
    if ((ahead > 1.3 || this.off) && d > 0.05) { speed = Math.min(6, 1.6 + (ahead - 1.3) * 1.6); const want = Math.atan2(dx, dz); let dh = want - this.h; dh = Math.atan2(Math.sin(dh), Math.cos(dh)); this.h += dh * Math.min(1, dt * 10); const st = Math.min(d, speed * dt); this.x += dx / d * st; this.z += dz / d * st; this.still = 0; }
    else { this.still += dt; if (this.still > 0.6) { const fo = Math.atan2(o.x - this.x, o.z - this.z); let dh = fo - this.h; dh = Math.atan2(Math.sin(dh), Math.cos(dh)); this.h += dh * Math.min(1, dt * 3); } }
    // hidden (like people) when it's inside a house Sam isn't in
    const inB = g.buildings.buildingAtPoint(this.x, this.z), hidden = (inB && !inB.def.open && !g.buildings.canSeeInto(inB)) || (!o.mesh.visible && !inB);
    this.root.visible = !hidden; if (hidden) return;
    const sitting = this.still > 2.5; this.sit += ((sitting ? 1 : 0) - this.sit) * Math.min(1, dt * 6);
    this.ph += speed * dt * 4.2; const run = Math.min(1, speed / 3), s = Math.sin(this.ph);
    this.legs[0].rotation.x = s * 0.9 * run; this.legs[1].rotation.x = -s * 0.9 * run; this.legs[2].rotation.x = -s * 0.9 * run + this.sit * -1.2; this.legs[3].rotation.x = s * 0.9 * run + this.sit * -1.2;
    this.body.rotation.x = -this.sit * 0.5; this.body.position.y = -this.sit * 0.13 + Math.abs(s) * 0.025 * run;
    this.tail.rotation.y = Math.sin(this.t * (sitting ? 9 : 6)) * (0.5 + this.sit * 0.3); this.tail.rotation.x = -0.5; this.head.rotation.x = Math.sin(this.t * 0.7) * 0.08 + (speed > 1 ? 0.15 : 0); this.head.rotation.y = Math.sin(this.t * 0.4) * 0.3 * (1 - run);
    this.root.position.set(this.x, 0, this.z); this.root.rotation.y = this.h;
  }
  /** Standing in the carriageway? Then the nearest bit of pavement (or verge) to go and wait on. */
  kerbside() {
    const w = this.game.world, [tx, tz] = w.tileOf(this.x, this.z); if (!w.inBounds(tx, tz) || w.road[w.idx(tx, tz)] !== 2) return null;   // footpaths are fine to sit on
    const T = 8, cx = (tx + 0.5) * T, cz = (tz + 0.5) * T, ox = this.x - cx, oz = this.z - cz, road = (x, z) => w.inBounds(x, z) && w.road[w.idx(x, z)] > 0;
    const sides = [];   // pavement runs along each side the road doesn't carry on through
    if (!road(tx - 1, tz)) sides.push({ x: cx - 3.2, z: this.z, d: Math.abs(ox + 3.2) }); if (!road(tx + 1, tz)) sides.push({ x: cx + 3.2, z: this.z, d: Math.abs(ox - 3.2) });
    if (!road(tx, tz - 1)) sides.push({ x: this.x, z: cz - 3.2, d: Math.abs(oz + 3.2) }); if (!road(tx, tz + 1)) sides.push({ x: this.x, z: cz + 3.2, d: Math.abs(oz - 3.2) });
    if (!sides.length) sides.push({ x: cx + Math.sign(ox || 1) * 3.6, z: cz + Math.sign(oz || 1) * 3.6, d: 0 });   // a crossroads: the corner
    const s = sides.sort((a, b) => a.d - b.d)[0]; return s.d < 0.6 ? null : { x: s.x, z: s.z };
  }
  dispose() { this.game.scene.remove(this.root); this.root.traverse((o) => { if (o.geometry) o.geometry.dispose(); }); }
}
