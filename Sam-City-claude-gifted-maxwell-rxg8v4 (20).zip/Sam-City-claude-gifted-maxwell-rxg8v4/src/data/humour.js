// Adult humour pack (18+): 1990s British telly-and-pub humour. Swearing, innuendo, Del Boy, Euro 96, Teletext.
// Mixed in with the normal lines when "Adult humour" is on. Children never use these. No slurs, no punching down.

export const A = {
  GREET: {
    stranger: ['Alright? You\'re Sam, aren\'t you? Thought you\'d be taller.', 'Oh, it\'s you. Everyone says you\'re a legend. I\'ll be the judge of that.', 'Hello, I\'m {first}. Don\'t mind the smell, I\'ve been in the chippy.', 'You\'re Sam? Bloody hell, you look like my cousin\'s first husband.'],
    acquaintance: ['Alright, Sam, you big jessie?', 'Sam! Still not dead, then?', 'Oi oi, saveloy!', 'Here he is! Or she is. Whatever. Here Sam is!', 'Watcha, Sam. You look rough as a badger\'s arse.'],
    friend: ['SAM! Get in! Pint later?', 'My favourite pillock! Come here!', 'Sam, you absolute legend. Lovely jubbly.', 'Alright, me old mucker? Kettle\'s on, biscuits are out, trousers optional.'],
    morning: ['Morning. My head\'s banging. Never again. Until Friday.', 'Too early, Sam. Way too early. Go away.', 'Morning! I\'ve had four coffees and I can see sounds.'],
    evening: ['Evening! Pub o\'clock, is it?', 'Nearly time for Gladiators. Ulrika! Ulrika!', 'Evening, Sam. My feet are killing me and my husband\'s snoring\'s worse.'],
    night: ['What you doing out this late? Up to no good, I bet. Me too.', 'Shh. I\'m not here. Neither are you. Deal?', 'If anyone asks, I was in bed by ten.'],
    rain: ['It\'s pissing down, Sam!', 'Rain again. Bloody marvellous.', 'I\'m wetter than an otter\'s pocket.', 'Absolutely chucking it down. Like Glastonbury without the music.'],
    visitor: ['Is it true you lot have a chip shop? We heard rumours.', 'Excuse me, where\'s the nearest pub? Asking for my husband. And me.', 'We came for the scenery. Stayed for the cheap lager.'],
  },
  MOOD: {
    happy: ['Happier than a dog with two willies, Sam.', 'Mint, mate. Absolutely mint.', 'I feel like Gazza after a goal. Before the knee.', 'Top of the world, Ma! Well, top of the village.', 'Lovely jubbly. This time next year we\'ll be millionaires.'],
    content: ['Can\'t complain. I do, mind. Constantly.', 'Same old shite, different day.', 'Not bad. Bit like a Pot Noodle: does the job.', 'Middling. Like a Blur B-side.'],
    fedup: ['I\'m hacked off, Sam. Properly.', 'Bit of a shit week, to be honest.', 'Don\'t start. I\'ve got a face like a slapped arse and I know it.', 'Fed up to the back teeth. And my teeth aren\'t great.'],
    miserable: ['I\'m bloody miserable. Even Noel Edmonds couldn\'t cheer me up.', 'Everything\'s gone tits up, Sam.', 'I want to crawl under a duvet and listen to The Smiths for a week.', 'Life\'s a bitch and then you build a village.'],
  },
  REASON: {
    hungry: ['I could eat a scabby horse.', 'I\'d sell my nan for a kebab right now.', 'Starving. I\'d even eat a Findus Crispy Pancake.', 'My belly\'s making noises like a dial-up modem.'],
    tired: ['I\'m knackered. Cream crackered.', 'Didn\'t sleep. Neighbours were at it like rabbits again.', 'I\'m so tired I could kip on a washing line.'],
    homeless: ['Got nowhere to kip. Sleeping in a hedge is not as romantic as it sounds.', 'No bed, Sam. I\'m one cardboard box away from a Big Issue stall.'],
    partner: ['{p} and me are getting on great. Mostly. Except the snoring. And the farting.', '{p} still makes my knees go funny. Could be arthritis, mind.', 'Me and {p}? Like Torvill and Dean, but skint.'],
    lonely: ['Haven\'t pulled since I got here. Not even close.', 'Bit lonely. Even the seagulls ignore me.'],
    newcomer: ['Only just got off the Lift. Still not sure what\'s going on, but the beer\'s cheap.', 'New here. Nobody warned me about the smell from the quarry.'],
    raid: ['Those raiders scared the living shite out of me.', 'Raiders! On a Tuesday! The cheek of it.'],
    work: ['Work\'s alright. Pays for the beer.', 'Work? Don\'t talk to me about work.'],
    nowork: ['No job. I\'ve been watching Countdown all day. I\'m getting good at the conundrum.', 'Signing on, Sam. Give us a job before I go mad.'],
  },
  WORK: {
    builder: ['Bum crack out, tea in hand, that\'s how a professional builds.', 'Tut. Who did this? Cowboys. Cost you, this will.', 'Me ladder\'s longer than your ladder.', 'I\'ll have it done by Friday. Which Friday, I couldn\'t tell you.'],
    lumberjack: ['I\'m a lumberjack and I\'m OK. Don\'t make me sing the rest.', 'Big wood, Sam. Biggest wood on the island. Stop sniggering.', 'Nearly took me own knob off with the axe this morning.'],
    forager: ['Picking berries all day. My hands look like I\'ve murdered a Smurf.', 'Found a mushroom that looked well dodgy. Left it. Probably.', 'Bushes, bushes, bushes. I dream about bushes. Stop smirking.'],
    fisher: ['Caught a whopper this morning. Don\'t look at me like that.', 'Fishing\'s just sitting still and drinking with a stick. Best job going.', 'Lost me tackle off the jetty. Again. Stop laughing.'],
    quarryman: ['Breaking rocks all day. I\'ve got biceps like a Gladiator. Like Wolf. Grr.', 'My hard hat\'s seen more action than I have.', 'Rocks don\'t talk back. Unlike my missus.'],
    farmer: ['Spent all morning with my arm up a cow. Don\'t ask.', 'Muck spreading season. You\'ll smell me before you see me.', 'Lovely big marrows this year. Lovely.'],
    publican: ['Last orders is a state of mind.', 'Bloke was sick in the fruit machine again.', 'The darts team\'s pissed already and it\'s a Tuesday.', 'Pint of mild? We\'re not animals, Sam. Have a lager.'],
    shopkeeper: ['Sold four copies of the Daily Sport and a Pot Noodle. Big day.', 'Someone nicked a Curly Wurly. I\'ll find them.', 'Top shelf\'s been restocked. Not that you\'d know about that.'],
    clerk: ['I file things. Then I unfile them. Then I file them again.', 'Twelve forms in triplicate for a bloody bench.', 'Office party was a disaster. Kevin photocopied his arse.'],
    teacher: ['Thirty kids, one of me, and they\'ve all got nits.', 'Someone wrote "Miss is a wazzock" on the board. Spelt it right, at least.'],
    doctor: ['Three people came in with things stuck where things shouldn\'t be stuck. Three!', 'Take two paracetamol and stop eating chips. Next!', 'You\'d be amazed what people slip on in the shower. Allegedly.'],
    guard: ['Ello ello ello, what\'s all this then?', 'Nicked a bloke for weeing in the fountain. Twice.', 'Crime\'s down. Mostly because I fell asleep.'],
    engineer: ['Have you tried turning it off and on again?', 'I hit it with a spanner. It works now. Engineering.', 'If it\'s not on fire, it\'s fine.'],
    factory: ['Same widget, eight hours, every day. Living the dream.', 'Machine ate my sandwich. Bastard.'],
    baker: ['Up at four, hands in dough. I\'m all about the buns, Sam.', 'Nice baps, Sam. The bread. I meant the bread.', 'My iced fingers sell like hot cakes. So do my hot cakes.'],
    fryer: ['Everything\'s better battered. Including me on a Friday.', 'Salt and vinegar? On everything. Including you.', 'Battered sausage, battered Mars bar, battered husband. I\'m joking. Mostly.'],
    vicar: ['The Lord moves in mysterious ways. So does the organist after a sherry.', 'Collection plate had a button, a betting slip and a Rolo in it.', 'Come to church on Sunday, Sam. We\'ve got biscuits. Rich Tea, but still.'],
    builderyard: [],
    child: [],
    visitor: ['Lovely place. Bit quiet. Where do you lot go to get hammered?', 'The wife wants a souvenir. I want a pint. We\'ll both lose.'],
    retired: ['I\'m retired. I do what I want. Today I want a nap and a moan.', 'In my day we had proper winters. And proper Opal Fruits.'],
    unemployed: ['I\'m between jobs. And between relationships. And between pants, if I\'m honest.', 'Still looking for work. Saw an advert for a pet food tester. Tempting.'],
  },
  GOSSIP: {
    couple: ['{a} and {b} are at it, apparently. Like rabbits. In the shed.', 'Did you see {a} and {b} snogging behind the chippy? Brazen!', '{a} has got the hots for {b}. Bless. It\'s like watching two pigeons.'],
    friends: ['{a} and {b} got hammered and sang "Wonderwall" outside my window till three.', '{a} and {b} are inseparable. Like Ant and Dec. Nobody knows which is which.'],
    newcomer: ['New bloke, {a}. Bit of a wally. Nice bum, though.', '{a} just arrived. Told everyone they used to be on Blockbusters. Lying, obviously.'],
    hungry: ['{a} looks starving. Ate a whole Fray Bentos pie cold out the tin, I saw it.', '{a} was eyeing up my dog. I think they were hungry. I hope they were hungry.'],
    building: ['The new {bld}? Looks like a wonky Lego set. I love it.', 'They\'ve finished the {bld}. Only took longer than the Channel Tunnel.', 'The {bld} is lovely. Someone\'s already graffitied a knob on the side.'],
    noFood: ['There\'s no food, Sam. People are eating Pot Noodles dry. It\'s like the war.', 'If I don\'t eat soon I\'m eating the vicar.'],
    noHomes: ['People are kipping in skips, Sam. Skips!', 'No houses. My brother-in-law\'s on my sofa. Again. Do something.'],
    raid: ['Them raiders. Proper hard nuts. One had a mullet.', 'Raiders came in a boat. From nowhere. There IS nowhere. Doesn\'t add up, does it?'],
    rain: ['It\'s raining so hard the ducks are wearing wellies.', 'Rain\'s ruined my perm. Again.'],
    growing: ['Town\'s getting big. Soon we\'ll have a Pizza Hut. A man can dream.', 'So many new faces. I\'ve given up learning names. Everyone\'s "mate" now.'],
    quiet: ['Nothing\'s happening. Even Teletext is more exciting.', 'Quiet week. I\'ve watched the test card for an hour.', 'Boring as a wet weekend in Rhyl.'],
    sam: ['Word is you\'re a bit of a sort, Sam.', 'Everyone fancies you, Sam. Well. Two people. One\'s the vicar.', 'They reckon you\'re the hardest worker here. And the sweatiest.'],
    pub: ['Pub quiz on Thursday. Last time {a} answered "Michael Barrymore" to every question.', 'Someone threw up in the pub plant pot. Third time this month.'],
  },
  ABOUT2: ['I once met Noel Edmonds. He was shorter than you\'d think.', 'I was at Euro 96. Cried like a baby at the penalties. Still not over it.', 'I\'m Oasis, not Blur. Fight me.', 'I\'m Blur, not Oasis. I have taste.', 'I\'ve seen every episode of Only Fools and Horses. Twice. The chandelier one, ten times.', 'I had a goldfish from the fair once. Won it on the hook-a-duck. Didn\'t last the week. I didn\'t cope well.', 'I can do the entire Macarena. Drunk or sober.', 'My ex ran off with a man who sold double glazing. Good riddance, but I miss the windows.', 'I still owe Blockbuster for a copy of Basic Instinct. From 1993.'],
  HELP: ['If in doubt, build a pub. That\'s my answer to everything.', 'Don\'t eat the yellow snow. Or the chippy\'s pickled eggs.', 'Tap the gold bit when you\'re working. Keep the chain going and it goes like the clappers.', 'Bigger village, bigger buildings. Get more people in, the Council coughs up new permits.', 'Can\'t get timber? Order it down the Lift. The intercom\'s on the post next to it.', 'Never trust a man in a shell suit.'],
  BYE: ['Laters, Sam!', 'Ta-ra, you big lump!', 'Catch you on the flip side.', 'Don\'t do anything I wouldn\'t do. That leaves you a lot of options.', 'Right, I\'m off to the pub. Don\'t tell the wife.', 'Toodle-pip, you absolute plum.'],
  BYE_GRUMPY: ['Sod off, then.', 'Bugger off. Nicely.', 'Yeah, yeah. Go on.'],
  // short speech bubbles between townsfolk
  CHAT: ['Bollocks!', 'You what?!', 'Get in!', 'Jammy git!', 'Sod that.', 'Cheeky!', 'Ooh, Matron!', 'Lovely jubbly.', 'Pillock.', 'Bloody hell!', 'Oi oi!', 'As if!', 'Talk to the hand.', 'Whatever!', 'Not!', 'Ace!', 'Wicked!', 'Did you see Gladiators?', 'Oasis or Blur?', 'Three Lions!', 'Shut your face.', 'Phwoar!', 'Behave!', 'You\'re having a laugh.', 'He\'s a right tosser.', 'Bit of a wally.', 'Swear down.', 'Mad for it!', 'Cowabunga!', 'Pint?', 'Cheers, big ears!', 'Hold my pint.', 'What a knob.', 'Spice up your life!'],
  SOCIAL_GREET: { cheerful: ['Oi oi, Sam!', 'Alright, gorgeous?', 'Sam! You sexy beast!', 'Wahey, it\'s Sam!'], grumpy: ['Oh, sod off.', 'What do YOU want?', 'Not you again.', 'Bugger me, it\'s Sam.'], shy: ['Oh... hi... sorry...', '*goes red*', 'Um. Nice... shoes.'], busy: ['Can\'t stop, busting for a wee!', 'Later, Sam!', 'No time, the chippy shuts at nine!'] },
  FETE: ['Who made this cake? It tastes like feet.', 'I won a goldfish! It\'s already dead.', 'Coconut shy! Mind your nuts!', 'Best in show, them marrows. Phwoar.', 'The tombola prize is a bottle of Lambrini. I\'m having it.', 'Morris dancers! Hide!', 'Three cheers for Sam! Hip hip!', 'The vicar\'s had too much Pimm\'s.', 'Hook-a-duck! I\'ve hooked a duck! Is that rude?', 'Guess the weight of the cake. Or the vicar.'],
  RAIDER: ['Give us your crisps!', 'Hand over the lager and nobody gets hurt!', 'Your mum\'s a pirate!', 'Nice village. Shame if something happened to it.', 'Oi! That\'s my plunder, you muppet!'],
  PUB: ['Same again?', 'Whose round is it?', 'This lager tastes like dishwater. Lovely.', 'One more and I\'m off. Honest.', 'I love you, mate. No, really. I love you.', 'Get the darts out!', 'Who put Robbie Williams on the jukebox?', 'Pork scratchings! Get in!'],
  CHURCH: ['Amen.', '*snore*', 'Is it nearly over?', 'He\'s been going on for an hour.', 'Lovely hymn. Shame about the singing.'],
  BAND: ['Is that a tuba or a cow?', 'Play some Oasis!', 'They\'re murdering it. Lovely.', 'Brass bands! Bloody brilliant.'],
  LETTERS: [
    ['Mrs Higginbottom, No. 4', 'Complaint', 'Dear Sam,\n\nSomeone keeps leaving their bins out and I know it\'s the man at No. 6 because I have seen his pants in them. Please do something.\n\nAlso, the seagulls are mocking me.\n\nYours, very cross'],
    ['Anonymous', 'A warning', 'Sam,\n\nThe Chip Shop is putting something in the batter. I don\'t know what, but my Kevin hasn\'t stopped smiling since Tuesday.\n\nA concerned citizen'],
    ['The Pub Quiz Team', 'Grand Final', 'Dear Sam,\n\n"Quiz Team Aguilera" invites you to the Grand Final this Thursday. Prize: a meat raffle and eternal glory.\n\nPlease don\'t bring Derek. He answered "Michael Barrymore" to every question last time.'],
    ['Your Secret Admirer', 'For Sam\'s eyes only', 'Sam,\n\nRoses are red,\nViolets are blue,\nI\'ve seen you chop timber,\nAnd I\'d like to chop you.\n\nWait, that came out wrong.\n\nxxx'],
    ['The Neighbourhood Watch', 'Suspicious activity', 'Dear Sam,\n\nA man in a shell suit has been seen lurking near the Lift at night. Then again, it might have been a bin bag. Hard to tell in this light.\n\nStay vigilant. And lock your shed.'],
    ['Dave from the Lift', 'Your order', 'Alright Sam,\n\nIf you want anything bringing down the Lift, use the intercom on the yellow post. Don\'t climb on the platform, the lads upstairs get twitchy.\n\nAlso, if you see my lighter, it\'s mine.\n\nDave'],
    ['The W.I.', 'Calendar', 'Dear Sam,\n\nWe are doing a charity calendar this year, tastefully nude, with strategically placed buns from the bakery. Mrs Pritchard is Miss March. You have been warned.\n\nThe Women\'s Institute'],
  ],
};

export const PHONE_CALLS = [
  ['The Speaking Clock', 'At the third stroke, it will be... no idea. The clocks here are fake. Beep. Beep. Beep.'],
  ['Your Mum', '"Sam? Is that you? Are you eating properly? Have you met someone nice? Your cousin\'s getting married. Again." Click.'],
  ['A Heavy Breather', '"Hhhhhh... hhhhhh..." "Sorry, wrong number, I\'ve been up the stairs." Click.'],
  ['Pizza Express', '"Sorry love, we don\'t deliver to... where did you say? Sam City? That\'s not on the map." Click.'],
  ['Dial-a-Joke', '"What do you call a man with a spade on his head? Doug. Without one? Douglas." You want your 50p back.'],
  ['The Lift Office', '"Lift Office. How did you get this number? Put the phone down, Sam. Put it down." Click.'],
  ['Teletext Holidays', '"Two weeks in Magaluf, all inclusive, £99! Oh, you\'re on an island already? Never mind." Click.'],
  ['The Samaritans', '"Hello, you\'re through to... oh, it\'s you again. Have you tried a cup of tea and a sit down?"'],
  ['Wrong Number', '"Is that the Chinese takeaway? No? Do you know their number? Do you want anything while I\'m ordering?"'],
  ['Your Ex', '"Oh. It\'s you." Click. Brutal.'],
  ['A Man Called Keith', '"Is Barry there? Tell Barry I want my lawnmower back. And my wife." Click.'],
  ['The Lottery Hotline', '"This week\'s numbers are 3, 7, 22... Not you, Sam. Never you." Click.'],
  ['Somebody Crying', '"...they\'ve cancelled Gladiators..." You hang up gently. Some grief is private.'],
  ['A Prank Caller', '"Is your fridge running? Then you\'d better go and catch it!" Classic. Absolute classic.'],
  ['Nobody', 'Just a dialling tone and the smell of wee. Very 1996.'],
];
export const PHONE_CALLS_CLEAN = [
  ['The Speaking Clock', 'At the third stroke, it will be... no idea. The clocks here are odd. Beep. Beep. Beep.'],
  ['Your Mum', '"Sam? Are you eating properly? Have you met someone nice?" Click.'],
  ['Dial-a-Joke', '"What do you call a man with a spade on his head? Doug!"'],
  ['The Lift Office', '"Lift Office. How did you get this number? Please hang up, Sam." Click.'],
  ['Wrong Number', '"Is that the Chinese takeaway? No? Sorry, love."'],
];

export const HORSES = ['Norfolk Enchants', 'Mr Blobby\'s Revenge', 'Lambrini Lass', 'Del Boy Dreams', 'Pot Noodle Prince', 'Gazza\'s Knee', 'Three Lions', 'Wonderwall', 'Sir Cliff', 'Teletext Page 302', 'Spice Bucket', 'Bum Note', 'Big Knockers', 'Hairy Biker', 'Saucy Sue', 'Pogs Galore', 'Shell Suit Sid', 'Fat Les', 'Cheeky Monkey', 'Bob\'s Full House'];
export const RACE_WIN = ['{h} romps home! You win £{w}! The bookie looks like he\'s swallowed a wasp.', 'Get in! {h} by a nose! £{w} in your sweaty hand.', '{h} wins! You do a little dance. The old boy by the telly calls you a jammy git. £{w}!'];
export const RACE_LOSE = ['{h} falls over at the first fence and has a little sit down. Your £{s} is gone.', '{h} stops to eat a hedge. You lose £{s}.', '{h} comes in last. Behind a dog that wandered onto the course. £{s} gone.', '{h} trips over its own feet. Like you on a Friday. £{s} down the drain.'];

// more grown-up 90s chatter (nineties.js)
import { N90 } from './nineties.js';
A.CHAT.push(...N90.chat); A.PUB.push(...N90.pub); A.GOSSIP.nineties = N90.gossipAdult;
import { N96 } from './nineties2.js';
A.CHAT.push(...N96.chat); A.PUB.push(...N96.pub); A.GOSSIP.nineties.push(...N96.gossipAdult);
